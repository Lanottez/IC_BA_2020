# -*- coding: utf-8 -*-
"""
Created on Sun Aug 27 10:08:11 2017

@author: artemis
"""

###NOTE
###Some parts of he file djia_returns_prediction_based_on_past_prices.py should be run prior 
###to the following code, otherwise errors will appear
 
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LinearRegression, Lasso, Ridge, ElasticNet, SGDRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import AdaBoostRegressor, RandomForestRegressor
from sklearn.svm import SVR

# Load data
sentiment1 = pd.read_csv("C://Users//artemis//Documents//BA_individual_report//sentiment_analysis_1.csv")
del sentiment1['Unnamed: 0']
sentiment1 = sentiment1[1: ] # delete the first row as we do not have data for djia returns on that date
sentiment1.columns = ['Sent_index']
sentiment2 = pd.read_csv("C://Users//artemis//Documents//BA_individual_report//sentiment_analysis_2.csv")
del sentiment2['Unnamed: 0']
del sentiment2['ID']


# Define the window size
window = 20


'''
CROSS-VALIDATION FUNCTION - WILL BE USED FOR TUNING PARAMETERS OF LASSO, RIDGE, RANDOM FOREST, ELASTIC NET
'''

#Create a function that defines cross validation folding for time series data - automative CV by scikit is not valid for time series data
def CV(X_train, y_train, number_folds):
    
    # k is the size of each fold. It is computed dividing the number of 
    # rows in X_train by number_folds. This number is floored and coerced to int
    k = int(np.floor(float(X_train.shape[0]) / number_folds))
    #create an empty list in which we will save our k-folds indexes 
    l = []
    # loop from the first 2 folds to the total number of folds 
    for i in range(2, number_folds + 1):
     
        split = float(i-1)/i
        X = X_train[:(k*i)]
        y = y_train[:(k*i)]

        # index is the integer telling us where to split, according to the split percentage we have set above
        index = int(np.floor(X.shape[0] * split))
        
        # folds used to train the model        
        X_trainFold = X[:index]    
        y_trainFolds = y[:index]
        
        # fold used to test the model
        X_testFold = X[(index + 1): X.shape[0]]
        y_testFold = y[(index + 1):]
                       
        l.append(([i for i in range(0, index)], [j for j in range(index, X.shape[0])]))
        ar = np.asarray(l)
        
    return(ar)

'''
SGD - LAGGED 3 DAYS - SENTIMENT 1
'''

window = 20

MSEallcurrSGD = np.zeros((1, 1)) 
MSEeachTimeallcurr= np.zeros(((sentiment1.shape[0]-(window+1)), 1)) 
coefs = []
X = sentiment1[['Sent_index']]
returns = pd.DataFrame(returns)
X = X.join(returns, how = 'inner')
X = X.iloc[ :-3, ] #defines a dataframe with all variables for an industry
target = sentiment1.iloc[3: ,] #define Y values - values to predict   
#Normalize data
X_norm = (X - X.mean()) / (X.max() - X.min()) 
target_norm = (target - target.mean()) / (target.max() - target.min()) 
# Get different alphas to test
alphas = 10**np.linspace(10,-5,20)*0.5
# Get different lambdas to test
l1_ratios = np.linspace(0,1,20)
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(sentiment1.shape[0]): 
    try:
        Xtrain = X.iloc[j-window:j] 
        ytrain = target.iloc[j-window +1:j+1] 
        SGD = SGDRegressor(random_state=12345)
        model = AdaBoostRegressor(SGD, random_state = 1991)
        grid = GridSearchCV(estimator=model, param_grid=dict(alpha=alphas), cv = CV(Xtrain, ytrain, 5)) #tuning hyper-parameters (alphas) using 5 fold cross-validation inside each window
        grid.fit(Xtrain, ytrain)
        optimal_estimators =  grid.best_estimator_.n_estimators
        # Fit ADABoostRegressor with Lasso model with best n_estimators
        SGD_boost = grid.best_estimator_
        SGD_boost.fit(Xtrain, ytrain.ravel())
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = SGD_boost.predict(predx.reshape(1,-1))
        diff = predvalue[0] - target.iloc[j + 2] 
        MSE = diff**2  
        acclist.append(float(MSE))
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k)
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] 
MeanErr = np.mean(error)  
MSEallcurrSGD= (MeanErr)    
rootSGD = np.sqrt(MSEallcurrSGD)  
outofsamp = RMAsqerror- rootSGD
RsqOOS = outofsamp # +0.001628962

# Save results
SGDRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
SGDRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//SGDRMSE_tweets1.csv")    



'''
SGD - LAGGED 3 DAYS - SENTIMENT 2
'''

window = 20

MSEallcurrSGD = np.zeros((1, 1)) 
MSEeachTimeallcurr= np.zeros(((sentiment2.shape[0]-(window+1)), 1)) 
coefs = []
X = sentiment2[['Returns', 'Sent_index']]
X = X.iloc[ :-3, ] #defines a dataframe with all variables for an industry
target = sentiment2.iloc[3: , 1] #define Y values - values to predict   
#Normalize data
X_norm = (X - X.mean()) / (X.max() - X.min()) 
target_norm = (target - target.mean()) / (target.max() - target.min()) 
# Get different alphas to test
alphas = 10**np.linspace(10,-5,20)*0.5
# Get different lambdas to test
l1_ratios = np.linspace(0,1,20)
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(sentiment2.shape[0]): 
    try:
        Xtrain = X.iloc[j-window:j] 
        ytrain = target.iloc[j-window +1:j+1] 
        SGD = SGDRegressor(random_state=12345)
        model = AdaBoostRegressor(SGD, random_state = 1991)
        grid = GridSearchCV(estimator=model, param_grid=dict(alpha=alphas), cv = CV(Xtrain, ytrain, 5)) #tuning hyper-parameters (alphas) using 5 fold cross-validation inside each window
        grid.fit(Xtrain, ytrain)
        optimal_estimators =  grid.best_estimator_.n_estimators
        # Fit ADABoostRegressor with Lasso model with best n_estimators
        SGD_boost = grid.best_estimator_
        SGD_boost.fit(Xtrain, ytrain.ravel())
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = SGD_boost.predict(predx.reshape(1,-1))
        diff = predvalue[0] - target.iloc[j + 2] 
        MSE = diff**2  
        acclist.append(MSE)
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k)
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] 
MeanErr = np.mean(error)  
MSEallcurrSGD= (MeanErr)    
rootSGD = np.sqrt(MSEallcurrSGD)  
outofsamp = RMAsqerror- rootSGD
RsqOOS = outofsamp # +0.00019343221368635366

# Save results
SGDRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
SGDRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//SGDRMSE_tweets2.csv")    


