# -*- coding: utf-8 -*-
"""
Created on Sun Aug 13 18:02:47 2017

@author: artemis
"""

from twitter import Twitter, OAuth
from time import sleep
from tqdm import tqdm
import datetime
import json
import csv
import tweepy
import math
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
import string
import pandas as pd
from collections import Counter, defaultdict
import re
from nltk.corpus import stopwords
import urllib.request as ur




''' TWITTER SCRAPING '''
'''https://github.com/bpb27/twitter_scraping/ was used as the base of this code'''

# Create a list of commonly used verbs to express feelings/emotions
verbs_expressing_emotios = ["i am", "i'm", "i feel", "i am feeling", "i'm feeling", "i don't feel", "makes me"]

# Find and save all tweets ids which contain the above verbs during the dates we are interested in
tweet_ids = {}
for verb in verbs_expressing_emotios:
    
    # define variables' values
    start = datetime(2015, 1, 2) 
    end = datetime(2017, 1, 31)  
    
    delay = 1  # time to wait on each page load before reading the page
    driver = webdriver.Chrome("C:\\Users\\artemis\\Anaconda3\\chromedriver_win32\\chromedriver.exe")
    
    # define initial variables
    twitter_ids_filename = 'all_ids.json'
    days = (end - start).days + 1
    id_selector = '.time a.tweet-timestamp'
    tweet_selector = 'li.js-stream-item'
    ids = []
    
    def format_day(date):
        day = '0' + str(date.day) if len(str(date.day)) == 1 else str(date.day)
        month = '0' + str(date.month) if len(str(date.month)) == 1 else str(date.month)
        year = str(date.year)
        return '-'.join([year, month, day])
    
    def form_url(since, until):
        v = verb.split(" ")
        if len(v) == 1:
            p1 = 'https://twitter.com/search?f=tweets&vertical=default&q="' + v[0] + '"'
        elif len(v) == 2:
            p1 = 'https://twitter.com/search?f=tweets&vertical=default&q="' + v[0] + '%20' + v[1] + '"'
        else:
            p1 = 'https://twitter.com/search?f=tweets&vertical=default&q="' + v[0] + '%20' + v[1] + '%20' + v[2] + '"'
        p2 = '%20since%3A' + since + '%20until%3A' + until + '&src=typd'
        return p1 + p2
        
    def increment_day(date, i):
        return date + timedelta(days=i)
    
    for day in range(days):
        d1 = format_day(increment_day(start, 0))
        d2 = format_day(increment_day(start, 1))
        url = form_url(d1, d2)
        driver.get(url)
        sleep(delay)
        
        try:
            found_tweets = driver.find_elements_by_css_selector(tweet_selector)
            increment = 10

            while len(found_tweets) >= increment:
                driver.execute_script('window.scrollTo(0, document.body.scrollHeight);')
                sleep(delay)
                found_tweets = driver.find_elements_by_css_selector(tweet_selector)
                increment += 10

            for tweet in found_tweets:
                try:
                    id = tweet.find_element_by_css_selector(id_selector).get_attribute('href').split('/')[-1]
                    ids.append(id)
                except StaleElementReferenceException as e:
                    print('lost element reference', tweet)

        except NoSuchElementException:
            print('no tweets on this day')

        start = increment_day(start, 1)

    print('total tweet count: ', len(set(ids)))
    driver.close()

    # Insert tweet ids per verb
    tweet_ids[verb] = ids
    
# Save results
with open('C://Users//artemis//Documents//BA_individual_report//tweet_ids.json', 'w') as output:
    json.dump(tweet_ids, output, sort_keys=True, indent=4)

# Keep only distinct tweet ids per expression-key
for k,v in tweet_ids.items():
    tweet_ids[k] = set(v)

# Merge all tweet ids in a common list
ids = []
for v in tweet_ids.values():
    for i in v:
        ids.append(i)
ids = list(set(ids)) # 152,637

# Get metadata (date & time, str_id, text content, source) of all tweets in our dictionary   
results = {}
with open('C:\\Users\\artemis\\Documents\\capstone_project\\api_keys.json') as f:
    keys = json.load(f) # Get Twitter API keys
auth = tweepy.OAuthHandler(keys['consumer_key'], keys['consumer_secret'])
auth.set_access_token(keys['access_token'], keys['access_token_secret'])
api = tweepy.API(auth)
    
all_data = []
start = 0
end = 100
limit = len(ids)
i = math.ceil(limit / 100)
    
for go in range(i):
    print('currently getting {} - {}'.format(start, end))
    sleep(6)  # needed to prevent hitting API rate limit
    id_batch = ids[start:end]
    start += 100
    end += 100
    tweets = api.statuses_lookup(id_batch)
    for tweet in tweets:
        all_data.append(dict(tweet._json))
        
    for item in all_data: 
        results[item["id"]] = {"created_at": item["created_at"], "text": item["text"], 
                               "id_str": item["id_str"], "source": item["source"]}

# Save results
with open('C://Users//artemis//Documents//BA_individual_report//results.json', 'w') as output:
    json.dump(results, output, sort_keys=True, indent=4)

