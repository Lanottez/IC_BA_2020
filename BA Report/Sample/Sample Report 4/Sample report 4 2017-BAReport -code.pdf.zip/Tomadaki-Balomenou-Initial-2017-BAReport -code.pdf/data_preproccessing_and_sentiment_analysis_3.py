# -*- coding: utf-8 -*-
"""
Created on Sun Aug 27 12:42:07 2017

@author: artemis
"""

from time import sleep
from tqdm import tqdm
import datetime
import json
import csv
import math
from datetime import datetime, timedelta
import string
import pandas as pd
from collections import Counter, defaultdict
import re
from nltk.corpus import stopwords
import urllib.request as ur


# Import data
with open('C://Users//artemis//Documents//BA_individual_report//results.json') as data_file:    
    results = json.load(data_file)
 
# Create a list of commonly used verbs to express feelings/emotions
verbs_expressing_emotios = ["i am", "i'm", "i feel", "i am feeling", "i'm feeling", "i don't feel", "makes me"]
        
    
''' DATA PREPARATION '''
    
# Change the date format
for k,v in results.items():
    d = [v['created_at'].split()[5]]
    d.append(v['created_at'].split()[1])
    d.append(v['created_at'].split()[2])
    date = ' '.join(d)
    v['created_at'] = datetime.strptime(date, "%Y %b %d").date()

# Remove spam messages (tweets that begin with 'http:' or 'www.')
spam_messages = [] # total = 36
for k,v in results.items():
    if re.match(r'^http:', v['text']): 
        spam_messages.append(k)
    if re.match(r'^https:', v['text']): 
        spam_messages.append(k)
    if re.match(r'^www.', v['text']):
        spam_messages.append(k)
results = {k: v for k, v in results.items() if k not in spam_messages}

#Remove additional white spaces
for k,v in results.items():
    v['text'] = re.sub('[\s]+', ' ', v['text'])
    
# Merge the text content of tweets in one signle text for each date
dates = []
for v in results.values():
    dates.append(v['created_at'])
dates = set(dates)

text_data = {}
for d in dates:
    for v in results.values():
        if v['created_at'] == d:
            if d not in text_data.keys():
                text_data[d] = v['text'] 
            else: 
                text_data[d] = text_data[d] + ' ' + v['text'] 

# Keep only tweets between 2015-01-02 and 2017-01-31 (due to twitter's advanced search engine function tweets of more dates are saved)
text_data = {k: v for k, v in text_data.items() if k >= datetime(2015, 1, 2).date() and k <= datetime(2017, 1, 31).date()}

# Convert @username to AT_USER and words that begin with 'http:' or 'www.' to LINKS_TO_BE_REMOVED
for k in text_data.keys():
    text_data[k] = re.sub('@[^\s]+','AT_USER', text_data[k])
    text_data[k] = re.sub('https:[^\s]+', 'LINKS_TO_BE_REMOVED', text_data[k])
    text_data[k] = re.sub('http:[^\s]+', 'LINKS_TO_BE_REMOVED', text_data[k])
    text_data[k] = re.sub('www.[^\s]+', 'LINKS_TO_BE_REMOVED', text_data[k])
    
# Remove punctuation
for k in text_data.keys():
    text_data[k] = "".join(l for l in text_data[k] if l not in string.punctuation)   

# Remove stop words  
stop = stopwords.words('english') + ['ATUSER'] + ['LINKSTOBEREMOVED'] + verbs_expressing_emotios + ['rt', 'via'] #rt is used for re-tweets and via is used to mention the original author of an article or a re-tweet                
for k in text_data.keys():
    if type(text_data[k]) is not list:
        text_data[k] = [x for x in text_data[k].split() if x not in stop]
    else:
        text_data[k] = [x for x in text_data[k] if x not in stop]

# Remove weekends (as the stock market is closed on weekends) and add weekends' tweets to Fridays' tweets
start = datetime(2015, 1, 2) 
end = datetime(2017, 1, 31)  
delta = timedelta(days=1)
d = start
weekend = set([5, 6])
days_witjout_weekends = []
weekends = []
while d <= end:
    if d.weekday() not in weekend:
        days_witjout_weekends.append(d.date())
    if d.weekday() in weekend:
        weekends.append(d.date())
    d += delta
 
delta = timedelta(days=1)
delta2 = timedelta(days=2)
for k in text_data.keys():
    if k in weekends:
        if (k-delta) not in weekends:
            text_data[k-delta] = text_data[k-delta] + text_data[k]
        if (k-delta) in weekends:
            text_data[k-delta2] = text_data[k-delta2] + text_data[k]
text_data = {k: v for k, v in text_data.items() if k not in weekends}

# Remove bank holidays (as the stock market is closed then) and add bank holidays' tweets to their previous day's tweets   
bank_holidays = []
djia = pd.read_csv('C://Users//artemis//Documents//BA_individual_report//DJIA_historicalprices.csv')
datess = djia.loc[ : , 'Date']
for d in days_witjout_weekends:
    if str(d) not in datess.tolist():
        bank_holidays.append(d)
        
delta = timedelta(days=1)
delta2 = timedelta(days=2)
delta3 = timedelta(days=3)
for k in text_data.keys():
    if k in bank_holidays and (k-delta) not in weekends:
        text_data[k-delta] = text_data[k-delta] + text_data[k]
    if k in bank_holidays and (k-delta) in weekends:
        if (k-delta2) not in weekends:
            text_data[k-delta2] = text_data[k-delta2] + text_data[k]
        if (k-delta2) in weekends:
            text_data[k-delta3] = text_data[k-delta3] + text_data[k]
            
text_data = {k: v for k, v in text_data.items() if k not in bank_holidays}

# Convert all text to lower case
for k,v in text_data.items():
    text_data[k] = list(map(lambda x:x.lower(),v))

# Remove empty whitespace strings from the lists of words
for k,v in text_data.items():
    text_data[k] = [item for item in v if item.strip()]
  
# Remove quotation marks from beginning or ending of a word
for k,v in text_data.items():
    for i in range(len(v)):
        #check if the word does not start with an alphabet letter
        val = None
        while val is None:
            val = re.search(r"^[a-zA-Z]", v[i])
            if val is not None:
                val = 0
            else:
                val = None
                v[i] = v[i][1: ]
                if v[i] == '':
                    val = 0
        #check if the word does not end in an alphabet letter
        val = None
        while val is None:
            val = re.search(r"[a-zA-Z]$", v[i])
            if val is not None:
                val = 0
            else:
                val = None
                v[i] = v[i][ :-1]
                if v[i] == '':
                    val = 0    

# Remove the empty strings that were created from the above procedure 
for k,v in text_data.items():
    text_data[k] = list(filter(None, v)) 
    
# Remove stop words that might be in capital before
for k,v in text_data.items():
    text_data[k] = [x for x in text_data[k] if x not in stop]
                  
# Replace repeating letters by a unique one
def repeating_letters(s):
    #look for 2 or more repetitions of character and replace with the character itself
    pattern = re.compile(r"(.)\1{1,}", re.DOTALL)
    return pattern.sub(r"\1\1", s)
for k,v in text_data.items():
    for i in range(len(v)):
        v[i] = repeating_letters(v[i])
            
# Spelling Correction (source: http://norvig.com/spell-correct.html)
total_list = []
for v in text_data.values():
    for item in v:
        total_list.append(item)
    
def words(text): return re.findall(r'\w+', text.lower())

WORDS = Counter(total_list)

def P(word, N=sum(WORDS.values())): 
    "Probability of `word`."
    return WORDS[word] / N

def correction(word): 
    "Most probable spelling correction for word."
    return max(candidates(word), key=P)

def candidates(word): 
    "Generate possible spelling corrections for word."
    return (known([word]) or known(edits1(word)) or known(edits2(word)) or [word])

def known(words): 
    "The subset of `words` that appear in the dictionary of WORDS."
    return set(w for w in words if w in WORDS)

def edits1(word):
    "All edits that are one edit away from `word`."
    letters    = 'abcdefghijklmnopqrstuvwxyz'
    splits     = [(word[:i], word[i:])    for i in range(len(word) + 1)]
    deletes    = [L + R[1:]               for L, R in splits if R]
    transposes = [L + R[1] + R[0] + R[2:] for L, R in splits if len(R)>1]
    replaces   = [L + c + R[1:]           for L, R in splits if R for c in letters]
    inserts    = [L + c + R               for L, R in splits for c in letters]
    return set(deletes + transposes + replaces + inserts)

def edits2(word): 
    "All edits that are two edits away from `word`."
    return (e2 for e1 in edits1(word) for e2 in edits1(e1))

for k,v in text_data.items():
    for i in range(len(v)):
        cor = correction(v[i])
        v[i] = cor

# Save matrix of tweets per day
text_data2 = {}
for key, list in text_data.items():
    text_data2[key] = ' '.join(list)        
tweets_matrix = pd.DataFrame(0, index = range(len(text_data)), columns = ['Date', 'Text'])   
i = 0
for k,v in text_data2.items():
    tweets_matrix.loc[i, 'Date'] = k
    tweets_matrix.loc[i, 'Text'] = v
    i += 1
    
# Save results to a csv file
tweets_matrix.to_csv('C://Users//artemis//Documents//BA_individual_report//tweets_matrix.csv')        
  
      
''' DATA PREPROCESSING FOR SENTIMENT ANALYSIS '''

# Save the text content of tweets in a list
tweets = []
for k,v in results.items():
    if v['created_at'] >= datetime(2015, 1, 2).date() and v['created_at'] <= datetime(2017, 1, 31).date():
        tweets.append(v['text'])
# Convert @username to AT_USER and words that begin with 'http:' or 'www.' to LINKS_TO_BE_REMOVED
for i in range(len(tweets)):
    tweets[i] = re.sub('@[^\s]+','AT_USER', tweets[i])
    tweets[i] = re.sub('https:[^\s]+', 'LINKS_TO_BE_REMOVED', tweets[i])
    tweets[i] = re.sub('http:[^\s]+', 'LINKS_TO_BE_REMOVED', tweets[i])
    tweets[i] = re.sub('www.[^\s]+', 'LINKS_TO_BE_REMOVED', tweets[i])
# Remove punctuation
for i in range(len(tweets)):
    tweets[i] = "".join(l for l in tweets[i] if l not in string.punctuation)   
# Remove stop words 
stop = stopwords.words('english') + ['ATUSER'] + ['LINKSTOBEREMOVED'] + verbs_expressing_emotios + ['rt', 'via'] #rt is used for re-tweets and via is used to mention the original author of an article or a re-tweet                
for i in range(len(tweets)):
    if type(tweets[i]) is not list:
        tweets[i] = [x for x in tweets[i].split() if x not in stop]
    else:
        tweets[i] = [x for x in tweets[i] if x not in stop]
# Convert all text to lower case
for i in range(len(tweets)):
    tweets[i] = map(lambda x:x.lower(),tweets[i])
# Remove empty whitespace strings from the lists of words
for i in range(len(tweets)):
    tweets[i] = [item for item in tweets[i] if item.strip()]  
# Remove quotation marks from beginning or ending of a word
for item in tweets:
    for i in range(len(item)):
        #check if the word does not start with an alphabet letter
        val = None
        while val is None:
            val = re.search(r"^[a-zA-Z]", item[i])
            if val is not None:
                val = 0
            else:
                val = None
                item[i] = item[i][1: ]
                if item[i] == '':
                    val = 0
        #check if the word does not end in an alphabet letter
        val = None
        while val is None:
            val = re.search(r"[a-zA-Z]$", item[i])
            if val is not None:
                val = 0
            else:
                val = None
                item[i] = item[i][ :-1]
                if item[i] == '':
                    val = 0    
# Remove the empty strings that were created from the above procedure 
for i in range(len(tweets)):
    tweets[i] = filter(None, tweets[i])
    # Remove verbes expressing feelings that might be in capital before
    tweets[i] = [x for x in tweets[i] if x not in stop]                
# Replace repeating letters by a unique one
def repeating_letters(s):
    #look for 2 or more repetitions of character and replace with the character itself
    pattern = re.compile(r"(.)\1{1,}", re.DOTALL)
    return pattern.sub(r"\1\1", s)
for item in tweets:
    for i in range(len(item)):
        item[i] = repeating_letters(item[i])    
# Spelling Correction 
for item in tweets:
    for i in range(len(item)):
        cor = correction(item[i])
        item[i] = cor

''' SENTIMENT ANALYSIS '''

# Calculate the document frequences 
DF_of_words = Counter()
for tweet in tweets:
    DF_of_words.update(set(tweet))

# Calculate the co-occurrent term frequences (takes time!!!)
DF_of_co = defaultdict(lambda : defaultdict(int))
for tweet in tqdm(tweets):
    for i in range(len(tweet)-1):            
        for j in range(i+1, len(tweet)):
            w1, w2 = sorted([tweet[i], tweet[j]])                
            if w1 != w2:
                DF_of_co[w1][w2] += 1
    sleep(0.01)

# Compute the probabilities
p_t = {}
p_t1_t2 = defaultdict(lambda : defaultdict(int))
for t1, n in DF_of_words.items():
    p_t[t1] = n / len(tweets)
    for t2 in DF_of_co[t1]:
        p_t1_t2[t1][t2] = DF_of_co[t1][t2] / len(tweets)

# Connect to positive on-line dictionary
filehandler = ur.urlopen('http://ptrckprry.com/course/ssd/data/positive-words.txt') 
positive_voc = []
for line in filehandler:
    positive_voc.append(line.strip())
positive_voc = positive_voc[35: ] # remove description
for i in range(len(positive_voc)):
    positive_voc[i] = positive_voc[i].decode("utf-8") # convert bytes to string
    
# Connect to negative on-line dictionary
filehandler = ur.urlopen('http://ptrckprry.com/course/ssd/data/negative-words.txt') 
negative_voc = []
for line in filehandler:
    negative_voc.append(line.strip())
negative_voc = negative_voc[35: ] # remove description
for i in range(len(negative_voc)):
    negative_voc[i] = negative_voc[i].decode('latin-1').encode("utf-8") # convert bytes/latin to string 
    negative_voc[i] = negative_voc[i].decode("utf-8") # convert bytes to string
    
# Compute PMI
pmi = defaultdict(lambda : defaultdict(int))
for t1 in p_t:
    for t2 in DF_of_co[t1]:
        denom = p_t[t1] * p_t[t2]
        pmi[t1][t2] = math.log2(p_t1_t2[t1][t2] / denom)
        
# Compute Semantic Orientation
semantic_orientation = {}
for term, n in p_t.items():
    positive_association = sum(pmi[term][tx] for tx in positive_voc)
    negative_association = sum(pmi[term][tx] for tx in negative_voc)
    semantic_orientation[term] = positive_association - negative_association
#Save results to a csv file
with open('C://Users//artemis//Documents//BA_individual_report//semantic_orientation.csv','wb') as f:
    w = csv.writer(f)
    w.writerow(semantic_orientation.keys())
    w.writerow(semantic_orientation.values())  
    
# Find the position of the negative words 'not' and 'dont'
negative_words = ['not', 'dont']
k = 0
position_of_tweet = {}
for tweet in text_data.values():
    position_of_words = []
    for i in range(len(tweet)):
        if tweet[i] in negative_words:
            position_of_words.append(i)
    position_of_tweet[k] = position_of_words
    k +=1

for k,tweet in text_data.items():
    for i in range(len(tweet)):
        if tweet[i] in positive_voc:
            tweet[i] = 1
        elif tweet[i] in negative_voc:
            tweet[i] = -1
        else:
            tweet[i] = 0

# Inverse the sign of words following negative words (not or dont)            
for k,v in position_of_tweet.items():
    key = datess[k]
    if v != []:
        for pos in v:
            try:
                text_data[key][pos+1] = -text_data[key][pos+1]
            except:
                break

# Compute the positive to negative tweets ratio per day
for k,list_scores in text_data.items():           
    neg_count = 0
    pos_count = 0
    for i in range(len(list_scores)):
        if list_scores[i] == -1:
            neg_count += 1
        if list_scores[i] == 1:
            pos_count += 1
    text_data[k] = pos_count/neg_count
            
# Save results
df = pd.DataFrame.from_dict(text_data, orient='index')   
df.to_csv('C://Users//artemis//Documents//BA_individual_report//sentiment_analysis_1.csv')


