library(ggplot2)
library(data.table)
library(DT)
library(syuzhet)
library(sentimentr)
library(corrplot)
library(gtable)
library(grid)
library(extrafont)
library(sjPlot)
library(readxl)

#load tweets
tweets_matrix <- read.csv("tweets_matrix.csv")
tweets_matrix$Date <- as.Date(as.character(tweets_matrix$Date), "%Y-%m-%d")
tweets_matrix<-tweets_matrix[order(tweets_matrix$Date),]
tweets_matrix <- tweets_matrix[2:nrow(tweets_matrix), c(2,3)]

#Convert to string
for(i in 1:nrow(tweets_matrix)) {
  tweets_matrix[i, 'Text'] <- toString(tweets_matrix[i, 'Text'])
}

#Calculate the numbers of words per sentiment:
sentiment <- get_nrc_sentiment(as.character(tweets_matrix$Text))

#Join a tabe with sentiments and dates
sent <- cbind(tweets_matrix$Date, sentiment)
colnames(sent)<-c("Date","Anger", "Anticipation", "Disgust", "Fear", "Joy", "Sadness", "Surprise", "Trust", "Negative", "Positive")

#Create a data frame with the frequency of each sentiment
sums<-as.data.frame(colSums(sent[,-1]))
colnames(sums)<-"Frequency"
sums$Sentiment<-rownames(sums)

#Bar plot - frequency of each sentiment
p <- ggplot(data=sums, aes(x=Sentiment, y=Frequency, fill=sums$Sentiment)) +
  geom_bar(stat="identity")+coord_flip() + theme(legend.position="none")
p + theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))

#Pie chart - frequency of each sentiment
bp <- ggplot(sums, aes(x = Sentiment, y = Frequency, fill = sums$Sentiment))+
  geom_bar(width = 1, stat = "identity")
bp + coord_polar("x", start = 0) + theme(legend.position = "none") + labs( x = "", y = "") + 
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12, face = "bold"))

#Data table - frequency of each sentiment
sum <- as.data.frame(sums[-2])
datatable(sum, options = list(dom = 't'))

###How is the emotional valence of the tweets across the time?
###We can analyze if the general sentiment of the tweets were negative or positive per day. We can use the package "sentimentr" and then plot the values versus the Dates:
dataf <- as.data.frame(sentiment_by(as.character(tweets_matrix$Text)))
tweets_matrix$ID <- seq.int(nrow(tweets_matrix))
df<-merge(tweets_matrix, dataf, by.x = "ID", by.y = "element_id")
df$Date <- as.Date(as.character(df$Date), "%Y-%m-%d")
ggplot(df, aes(x=Date, y=ave_sentiment))+geom_line()+geom_hline(yintercept=0, colour="red", size=1.5)+ labs(x="Time",y="Emotional valence") 

##Are there some interesting patterns to show us the way?
#stock returns data frame
#load our data
data <- read.csv("returns.csv")
data <- data[,2:3]
#Tweets data frame
tweets <- read.csv("tweets_matrix.csv")
tweets$Date <- as.Date(as.character(tweets$Date), "%Y-%m-%d")
tweets<-tweets[order(tweets$Date),]
tweets<-tweets[2:nrow(tweets),2:3]

#Sentiments words table:
sentiment <- get_nrc_sentiment(as.character(tweets$Text))
sent <- cbind(tweets$Date, sentiment)
colnames(sent)<-c("Date","Anger", "Anticipation", "Disgust", "Fear", "Joy", "Sadness", "Surprise", "Trust", "Negative", "Positive")

#Sentiment index
sent_index <- as.data.frame(sentiment_by(as.character(tweets$Text)))
colnames(sent_index)<-c("ID", "Word_Count", "sd", "Sent_index")

#Join tables 
ID <- seq.int(nrow(data))
dfa<-cbind(data, sent)
dfa<-cbind(ID, dfa)
df<-merge(dfa, sent_index, by.x="ID", by.y="ID")
df <- df[,-4]
datatable(df)

#How are the variables correlated? (used the tweets of the last day and the djia indexes returns of the next day)
cor_jnk=round(cor(df[sapply(df, is.numeric)], use="complete.obs"),2)

corrplot(cor_jnk,  method="circle", tl.pos="lt", type="full",        
         tl.col="black", tl.cex=0.7, tl.srt=45, 
         addCoef.col="black", addCoefasPercent = TRUE,
         p.mat = 1-abs(cor_jnk), sig.level=0.50, insig = "blank", number.cex = 1, title=" ", mar=c(0,0,2,0))

#How is the change of the djia indexes returns related with the sentiment index (Emotional valence)?:
df$Date <- as.Date(as.character(df$Date), "%Y-%m-%d")
par(mar=c(5,4,4,7)+.1)
plot(df$Date, df$Returns, type="l", col="red", ylab="DJIA Change (%)", xlab="Date")
par(new=TRUE)
plot(df$Date, df$Sent_index,type="l",col="blue",xaxt="n",yaxt="n",xlab="",ylab="")
axis(4)
mtext("Emotional valence",side=4,line=3)
legend("topright",col=c("red","blue"),lty=1,legend=c("DJIA","Sent. Index"))

###Some points:
###Sentiments of the news are related with the negocited volume and the absolute daily variation of the Dow Jones. I think this relationship can be improved with more specialized news and not from a general news source . 
###Once this relationship is improved, I think the possibility to predict a binary variation of the DJ index can be performed with some accuracy. 

#export news data frame into a csv file
write.csv(df, "sentiment_analysis_2.csv")
