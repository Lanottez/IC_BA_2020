# -*- coding: utf-8 -*-
"""
Created on Sat Aug 19 12:39:39 2017

@author: artemis
"""

import pandas as pd
import numpy as np 
from sklearn.linear_model import LinearRegression, Lasso, Ridge, ElasticNet, SGDRegressor
from sklearn.ensemble import AdaBoostRegressor, RandomForestRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVR

#Load our data 
data = pd.read_csv("C://Users//artemis//Documents//BA_individual_report//DJIA_historicalprices.csv")
data = data.iloc[:, (0, 5)]

# Calculate returns based on adjusted closing prices
returns = []
for i in range(1, data.shape[0]):
    returns.append((data.loc[i, 'Adj Close'] - data.loc[(i-1), 'Adj Close'])/data.loc[(i-1), 'Adj Close'])

# Create a new data frame with dates and returns as columns
data = pd.DataFrame(data = data.iloc[1: , 0])
data.loc[ : , 'Returns'] = returns

#Save results
data.to_csv('C://Users//artemis//Documents//BA_individual_report//returns.csv')

'''
OPTIMAL WINDOW SIZE USING 5 FOLD CROSS VALIDATION FOR TIME SERIES DATA
'''
windows = [15, 20, 25, 30, 40, 50, 70, 80, 100, 125, 150, 200]

optimal_windows = []
coefs = []
X = data.iloc[ : , 1] 
target = data.iloc[ : , 1]    
error_window = [] 
for w in windows:
    for j in range(w, (X.shape[0] - 1)): 
        Xtrain = X.iloc[j-w:j] 
        ytrain = target.iloc[j-w +1:j+1] 
        number_folds = 5
        k = int(np.floor(float(Xtrain.shape[0]) / number_folds))
        acclist = []
        #cross-validation for the optimal window size
        for f in range(2, number_folds + 1):
            split = float(f-1)/f
            X_f = Xtrain[:(k*f)]
            y_f = ytrain[:(k*f)]        
            # index is the integer telling us where to split, according to the split percentage we have set above
            index = int(np.floor(X_f.shape[0] * split))
            # folds used to train the model        
            X_trainFold = X_f[:index]    
            y_trainFold = y_f[:index]
            # fold used to test the model
            X_testFold = X_f[(index + 1):]
            y_testFold = y_f[(index + 1):]
            lin = LinearRegression()
            X_trainFold = X_trainFold.reshape((index,1))
            y_trainFold = y_trainFold.reshape((index,1))            
            lin.fit(X_trainFold,np.array(y_trainFold).ravel()) 
            predx = X_testFold
            predx = predx.reshape((len(predx),1))
            y_testFold = y_testFold.reshape((len(y_testFold),1))            
            predvalues = lin.predict(predx)  
            difference = predvalues - y_testFold 
            SqE = difference**2
            if len(SqE) > 1:
                acclist.append(float(np.mean(SqE)))
            elif len(SqE) == 1:
                acclist.append(float(SqE))
    werror = np.mean(acclist)
    error_window.append((np.mean(werror)))
        
minimum = 1000000000
for er in range(0, len(error_window)):
    if error_window[er] < minimum:
        minimum = error_window[er]
        optimal_window = windows[er] # 20
       
#define length of window
window = 20


'''
HISTORICAL AVERAGE
'''
# Historical Average
MAcurr = np.zeros((523, 1))
y = data.iloc[:, 1] #Y values
avglist = []
for i in range(len(y)):
    if i - window >= 0:
        try:
            avg = np.mean(y.iloc[i-window:i]) #calculates the average return of each window for each industry
        except:
            avg = 'nan'
        MAcurr[i] = avg
MAcurr = MAcurr[window:,:] #takes the data from t = window and later (data before that time equal 0)

# Error of Historical Average           
MAallsqerror = np.zeros((len(MAcurr), 1))
MAsqerror = np.zeros((1, 1)) #gives the MSE for each industry over the entire period
actual = data[window:][[1]] #takes actual values beyond the window
estimate = MAcurr #takes the predicted values - made with the function in the section above
for i in range(0, len(MAcurr)):
    sqdiff = (estimate[i] - float(actual.iloc[i]))**2 #squares the diff
    MAallsqerror[i] = sqdiff #put in the above defined 2D array - showing all errors for all industries at each t
MAsqerror = np.mean(MAallsqerror)
RMAsqerror = np.sqrt(MAsqerror)

# Save results
HistoricalMeandf = pd.DataFrame(data = MAallsqerror)
HistoricalMeandf.to_csv("C://Users//artemis//Documents//BA_individual_report//HistoricalMean.csv")


'''
OPTIMAL LAGGED RETURNS USING 5 FOLD CROSS VALIDATION FOR TIME SERIES DATA
'''

lagged_days = [1, 2, 3, 4, 7, 15, 30, 60] 
error_lagged_days = [] 
for l in lagged_days:
    coefs = []
    X = data.iloc[ :-l, 1] 
    target = data.iloc[l: , 1]     
    for j in range(window, (X.shape[0] - 1)): 
        Xtrain = X.iloc[j-window:j] 
        ytrain = target.iloc[j-window +1:j+1] 
        number_folds = 5
        k = int(np.floor(float(Xtrain.shape[0]) / number_folds))
        acclist = []
        #cross-validation for the optimal lagged day size
        for f in range(2, number_folds + 1):
            split = float(f-1)/f
            X_f = Xtrain[:(k*f)]
            y_f = ytrain[:(k*f)]
            # index is the integer telling us where to split, according to the split percentage we have set above
            index = int(np.floor(X_f.shape[0] * split))
            # folds used to train the model        
            X_trainFold = X_f[:index]    
            y_trainFold = y_f[:index]
            # fold used to test the model
            X_testFold = X_f[(index + 1):]
            y_testFold = y_f[(index + 1):]
            # make the prediction   
            lin = LinearRegression()
            X_trainFold = X_trainFold.reshape((index,1))
            y_trainFold = y_trainFold.reshape((index,1))
            lin.fit(X_trainFold, y_trainFold)
            predx = X_testFold
            predx = predx.reshape((len(predx),1))
            y_testFold = y_testFold.reshape((len(y_testFold),1))
            predvalues = lin.predict(predx)  
            difference = predvalues - y_testFold 
            SqE = difference**2
            if len(SqE) > 1:
                acclist.append(float(np.mean(SqE)))
            elif len(SqE) == 1:
                acclist.append(float(SqE))
    lerror = np.mean(acclist)
    error_lagged_days.append((np.mean(lerror)))
    
minimum = 1000000000
for er in range(0, len(error_lagged_days)):
    if error_lagged_days[er] < minimum:
        minimum = error_lagged_days[er]
        optimal_lagged_days = lagged_days[er] # 3 lagged days give the smallest error (1.1930292304733545e-05)
        
        
'''
LINEAR REGRESSION - LAGGED 1 DAY
''' 
MSEallcurr = np.zeros((1, 1)) # this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((521 - (window+1)), 1)) #this array stores all of the squared errors for each industry at each period    
coefs = []
X = data.iloc[:-1, 1] #define a dataframe with all variables for an industry
target = data.iloc[1:, 1] #define Y values - values to predict
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(523): #making a prediction for every value of the target column
    try:
        Xtrain = X.iloc[j-window:j] #takes window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        lin = LinearRegression()
        Xtrain = Xtrain.reshape((len(Xtrain),1))
        ytrain = ytrain.reshape((len(ytrain),1))
        lin.fit(Xtrain,ytrain) #fits a linear reg on this window of data
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = lin.predict(predx.reshape(1,-1)) #reformats into an array - plug these into the trained model 
        diff = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        MSE = diff**2  #just squared error
        acclist.append(MSE)
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k)#taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each prediction
MeanErr = np.mean(error) #mean squared error 
MSEallcurr = (MeanErr)
rootMSE = np.sqrt(MSEallcurr)     
outofsamp = RMAsqerror - rootMSE
RsqOOS = outofsamp # -0.00054744933657184351

# Save results
LinearRegRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
LinearRegRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//LinearRegRMSE_lagged1.csv")


'''
LINEAR REGRESSION - LAGGED 3 DAYS
''' 
MSEallcurr = np.zeros((1, 1)) # this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((519 - (window+1)), 1)) #this array stores all of the squared errors for each industry at each period    
coefs = []
X = data.iloc[:-3, 1] #define a dataframe with all variables for an industry
target = data.iloc[3:, 1] #define Y values - values to predict
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(523): #making a prediction for every value of the target column
    try:
        Xtrain = X.iloc[j-window:j] #takes window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        lin = LinearRegression()
        Xtrain = Xtrain.reshape((len(Xtrain),1))
        ytrain = ytrain.reshape((len(ytrain),1))
        lin.fit(Xtrain,ytrain) #fits a linear reg on this window of data
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = lin.predict(predx.reshape(1,-1)) #reformats into an array - plug these into the trained model 
        diff = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        MSE = diff**2  #just squared error
        acclist.append(MSE)
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k)#taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each prediction
MeanErr = np.mean(error) #mean squared error 
MSEallcurr = (MeanErr)
rootMSE = np.sqrt(MSEallcurr)     
outofsamp = RMAsqerror - rootMSE
RsqOOS = outofsamp # -0.00020467668404878549

# Save results
LinearRegRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
LinearRegRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//LinearRegRMSE_lagged3.csv")

'''
LINEAR REGRESSION - LAGGED 30 DAYS
''' 
MSEallcurr = np.zeros((1, 1)) # this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((519 - (window+1)), 1)) #this array stores all of the squared errors for each industry at each period    
coefs = []
X = data.iloc[:-30, 1] #define a dataframe with all variables for an industry
target = data.iloc[30:, 1] #define Y values - values to predict
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(523): #making a prediction for every value of the target column
    try:
        Xtrain = X.iloc[j-window:j] #takes window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        lin = LinearRegression()
        Xtrain = Xtrain.reshape((len(Xtrain),1))
        ytrain = ytrain.reshape((len(ytrain),1))
        lin.fit(Xtrain,ytrain) #fits a linear reg on this window of data
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = lin.predict(predx.reshape(1,-1)) #reformats into an array - plug these into the trained model 
        diff = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        MSE = diff**2  #just squared error
        acclist.append(MSE)
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k)#taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each prediction
MSEeachTimeallcurr = MSEeachTimeallcurr[0:471]
MeanErr = np.mean(error) #mean squared error 
MSEallcurr = (MeanErr)
rootMSE = np.sqrt(MSEallcurr)     
outofsamp = RMAsqerror - rootMSE
RsqOOS = outofsamp # -0.00024060749967781507

# Save results
LinearRegRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
LinearRegRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//LinearRegRMSE_lagged30.csv")

'''
ADA BOOST REGRESSION - LAGGED 3 DAYS 
''' 
MSEallcurrADA = np.zeros((1, 1)) #this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((522-(window+1)), 1)) #this array stores all of the squared errors for each industry at each period
coefs = []
X = data.iloc[ :-3 , 1] #defines a dataframe with all variables for a currency
target = data.iloc[3: , 1] #defines Y values - values to predict
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(522): #making a prediction for every value of the target column
    try:
        Xtrain = X.iloc[j-window:j] #takes window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        lin = AdaBoostRegressor()
        Xtrain = Xtrain.reshape((len(Xtrain),1))
        ytrain = ytrain.reshape((len(ytrain),1))
        lin.fit(Xtrain,ytrain.ravel()) #fits an ADA boost regression on this window of data
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = lin.predict(predx.reshape(1,-1)) #reformats into an array - plug these into the trained model 
        diff = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        MSE = diff**2  #just squared error
        acclist.append(MSE)
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k) #taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each predictions
MeanErr = np.mean(error) #mean squared error 
MSEallcurrADA = (MeanErr)   
rootADA = np.sqrt(MSEallcurrADA)  
outofsamp = RMAsqerror - rootADA
RsqOOS = outofsamp # -0.0025276278599952445

# Save results
ADARMSE = pd.DataFrame(data=MSEeachTimeallcurr)
ADARMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//ADARMSE.csv")

'''
CROSS-VALIDATION FUNCTION - WILL BE USED FOR TUNING PARAMETERS OF LASSO, RIDGE, RANDOM FOREST, ELASTIC NET
'''

#Create a function that defines cross validation folding for time series data - automative CV by scikit is not valid for time series data
def CV(X_train, y_train, number_folds):

    # k is the size of each fold. It is computed dividing the number of 
    # rows in X_train by number_folds. This number is floored and coerced to int
    k = int(np.floor(float(X_train.shape[0]) / number_folds))
    #create an empty list in which we will save our k-folds indexes 
    l = list()
    # loop from the first 2 folds to the total number of folds 
    for i in range(2, number_folds + 1):
     
        split = float(i-1)/i
        X = X_train[:(k*i)]
        y = y_train[:(k*i)]

        # index is the integer telling us where to split, according to the split percentage we have set above
        index = int(np.floor(X.shape[0] * split))
        
        # folds used to train the model        
        X_trainFold = X[:index]    
        y_trainFolds = y[:index]
        
        # fold used to test the model
        X_testFold = X[(index + 1): X.shape[0]]
        y_testFold = y[(index + 1):]
                       
        l.append(([i for i in range(0, index)], [j for j in range(index, X.shape[0])]))
        ar = np.asarray(l)
        
    return(ar)
    

'''
LASSO INCLUDING LAGS 1, 3 & 30 LAGGED DAYS VARIABLES & OIL AND GOLD PAST PRICES + ADA BOOST REGRESSOR
'''
data_lagged = pd.read_excel("C://Users//artemis//Documents//BA_individual_report//Lagged_1_2_30_gold_oil.xlsx")

MSEallcurrLasso = np.zeros((1, 1)) #this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((509-(window+1)), 1)) #this array stores all of the squared errors for each industry at each period 
optimalalpha = np.zeros((509, 1))
# prepare parameters to be tuned with ADA boosting
parameters = {'n_estimators' : range(2,50,2), 
              'learning_rate' : [0.001,0.05,0.1,0.3,0.8,1,1.5,2,4,5]
              }
              
coefs = []
X = data_lagged.iloc[ : , :] #define a dataframe with all variables for an industry
target = data.iloc[30:, 1] #define Y values - values to predict   
acclist = [] #a list of the squared error of all predictions made for an industry 
for j in range(window, 509): 
    try:
        Xtrain = X.iloc[j-window:j] #takes window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        lasso = Lasso(alpha = optimal_alpha, max_iter = 100000, normalize = True, random_state = 1991)
        model = AdaBoostRegressor(lasso, random_state = 1991)
        grid = GridSearchCV(estimator = model, param_grid = parameters, cv = CV(Xtrain, ytrain, 5), n_jobs = 4)
        grid.fit(Xtrain, ytrain.ravel())
        optimal_estimators =  grid.best_estimator_.n_estimators
        # Fit ADABoostRegressor with Lasso model with best n_estimators
        lasso_boost = grid.best_estimator_
        lasso_boost.fit(Xtrain, ytrain.ravel())
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = lasso_boost.predict(predx.reshape(1,-1)) #reformats into an array - plug these into the trained model 
        difference = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        SqE = difference**2
        acclist.append(SqE)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k) #taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each prediction
MeanErr = np.mean(error) #mean squared error 
MSEallcurrLasso = (MeanErr)
rootLasso = np.sqrt(MSEallcurrLasso)
outofsamp = RMAsqerror - rootLasso
RsqOOS = outofsamp # -0.00012931931021399785

# Save results
LassoRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
LassoRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//LassoRMSE_lag1_3_30.csv")


'''
RIDGE INCLUDING LAGS 1, 3 & 30 LAGGED DAYS VARIABLES & OIL AND GOLD PAST PRICES + ADA BOOST REGRESSOR
'''
data_lagged = pd.read_excel("C://Users//artemis//Documents//BA_individual_report//Lagged_1_2_30_gold_oil.xlsx")

MSEallcurrLasso = np.zeros((1, 1)) #this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((509-(window+1)), 1)) #this array stores all of the squared errors for each industry at each period 
optimalalpha = np.zeros((509, 1))
# prepare a range of alpha values to test
alphas = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1])

coefs = []
X = data_lagged.iloc[ : , :] #define a dataframe with all variables for an industry
target = data.iloc[30:, 1] #define Y values - values to predict   
acclist = [] #a list of the squared error of all predictions made for an industry 
for j in range(window, 509): 
    try:
        Xtrain = X.iloc[j-window:j] #takes window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        ridge = Ridge(max_iter = 100000, normalize = True)
        model = AdaBoostRegressor(ridge, random_state = 1991)
        grid = GridSearchCV(estimator=model, param_grid=dict(alpha=alphas), cv = CV(Xtrain, ytrain, 5)) #tuning hyper-parameters (alphas) using 5 fold cross-validation inside each window
        grid.fit(Xtrain, ytrain)
        optimal_estimators =  grid.best_estimator_.n_estimators
        # Fit ADABoostRegressor with Lasso model with best n_estimators
        ridge_boost = grid.best_estimator_
        ridge_boost.fit(Xtrain, ytrain.ravel())
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = ridge_boost.predict(predx.reshape(1,-1))
        difference = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        SqE = difference**2
        acclist.append(SqE)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k) #taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each prediction
MeanErr = np.mean(error) #mean squared error 
MSEallcurrLasso = (MeanErr)
rootLasso = np.sqrt(MSEallcurrLasso)
outofsamp = RMAsqerror - rootLasso
RsqOOS = outofsamp # -0.0021985413579434666

# Save results
RidgeRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
RidgeRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//RidgeRMSE.csv")
 
'''
ELASTIC NET INCLUDING LAGS 1, 3 & 30 LAGGED DAYS VARIABLES & OIL AND GOLD PAST PRICES + ADA BOOST REGRESSOR
'''
data_lagged = pd.read_excel("C://Users//artemis//Documents//BA_individual_report//Lagged_1_2_30_gold_oil.xlsx")

MSEallcurrLasso = np.zeros((1, 1)) #this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((509-(window+1)), 1)) #this array stores all of the squared errors for each industry at each period 
optimalalpha = np.zeros((509, 1))
# prepare a range of alpha values to test
alphas = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1])

coefs = []
X = data_lagged.iloc[ : , :] #define a dataframe with all variables for an industry
target = data.iloc[30:, 1] #define Y values - values to predict   
acclist = [] #a list of the squared error of all predictions made for an industry 
for j in range(window, 509): 
    try:
        Xtrain = X.iloc[j-window:j] #takes window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        ElNet = ElasticNet(max_iter = 100000, normalize = True)
        model = AdaBoostRegressor(ElNet, random_state = 1991)
        grid = GridSearchCV(estimator=model, param_grid=dict(alpha=alphas), cv = CV(Xtrain, ytrain, 5)) #tuning hyper-parameters (alphas) using 5 fold cross-validation inside each window
        grid.fit(Xtrain, ytrain)
        optimal_estimators =  grid.best_estimator_.n_estimators
        # Fit ADABoostRegressor with Lasso model with best n_estimators
        ElNet_boost = grid.best_estimator_
        ElNet_boost.fit(Xtrain, ytrain.ravel())
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = ElNet_boost.predict(predx.reshape(1,-1))
        difference = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        SqE = difference**2
        acclist.append(SqE)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k) #taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each prediction
MeanErr = np.mean(error) #mean squared error 
MSEallcurrLasso = (MeanErr)
rootLasso = np.sqrt(MSEallcurrLasso)
outofsamp = RMAsqerror - rootLasso
RsqOOS = outofsamp #-0.00012931931021399785

# Save results    
ElasticRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
ElasticRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//ElasticRMSE_kitchensink.csv")  


'''
RANDOM FOREST - LAGGED 3 DAYS + ADA BOOST REGRESSOR
'''
MSEallcurrRF1 = np.zeros((1, data.shape[1])) #this array stores the MSE for each industry for all predictions 
MSEeachTimeallcurr= np.zeros(((522-(window+1)), data.shape[1])) #this array stores all of the squared errors for each industry at each period
# prepare a range of tree values to be tuned
trees = np.array([1, 5, 10, 20, 50, 60, 70, 80, 90, 100])
# prepare a range of leave values to be tuned
leaves = np.array([1,2,3,5])

coefs = []
X = data.iloc[ :-3, 1] #defines a dataframe with all variables for an industry
target = data.iloc[3: , 1] #define Y values - values to predict   
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(window, 522): 
    try:
        Xtrain = X.iloc[j-window:j] #takse window of traing samples
        ytrain = target.iloc[j-window +1:j+1] #takes window of outcomes that are shifted forwards 1
        RF = RandomForestRegressor(random_state = 0)
        model = AdaBoostRegressor(RF, random_state = 1991)
        grid = GridSearchCV(estimator=model, param_grid=dict(alpha=alphas), cv = CV(Xtrain, ytrain, 5)) #tuning hyper-parameters (alphas) using 5 fold cross-validation inside each window
        grid.fit(Xtrain, ytrain)
        optimal_estimators =  grid.best_estimator_.n_estimators
        # Fit ADABoostRegressor with Lasso model with best n_estimators
        RF_boost = grid.best_estimator_
        RF_boost.fit(Xtrain, ytrain.ravel())
        predx = X.iloc[j+1] #takes the next x values to predict corresponding y  
        predvalue = RF_boost.predict(predx.reshape(1,-1))
        difference = predvalue[0] - target.iloc[j + 2] #takes the difference between the next predicted + actual values
        SqE = difference**2
        acclist.append(SqE)
    except:
        acclist.append('nan')            
error = []
for k in acclist:
    if k != 'nan':
        error.append(k) #taking only precitions, leaving out nan's
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] #taking the squared error for each prediction
MeanErr = np.mean(error) #mean squared error 
MSEallcurrRF2 = (MeanErr)
rootRF2 = np.sqrt(MSEallcurrRF2)
outofsamp = RMAsqerror - rootRF2
RsqOOS = outofsamp # -0.00071632373195992111

# Save results
RandomForestRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
RandomForestRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//RandomForestRMSE_.csv")  
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

'''
Support Vector Regression - LAGGED 3 DAYS + ADA BOOST REGRESSOR
''' 

MSEallcurrSVR = np.zeros((1, 1))
MSEeachTimeallcurr= np.zeros(((data.shape[0]-(window+1)), 1)) 
tuned_parameters_rbf = [{'kernel': ['rbf'], 'gamma': [1e-3, 1e-4],'C': [1, 10, 100, 1000]}]
coefs = []
X = data.iloc[ :-3, 1] #defines a dataframe with all variables for an industry
target = data.iloc[3: , 1] #define Y values - values to predict   
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(window, data.shape[0]):
    try:
        Xtrain = X.iloc[j-window:j] 
        ytrain = target.iloc[j-window +1:j+1] 
        model = SVR()
        grid = GridSearchCV(estimator = model, param_grid = tuned_parameters_rbf, cv = CV(Xtrain, ytrain, 5))
        Xtrain = Xtrain.reshape((len(Xtrain), 1))
        ytrain = ytrain.reshape((len(ytrain), 1))        
        grid.fit(Xtrain,ytrain.ravel()) 
        optimal_model = grid.best_estimator_
        lin = optimal_model
        predx = X.iloc[j+1] 
        predvalue = lin.predict(predx.reshape(1,-1))
        diff = predvalue[0] - target.iloc[j + 2]
        MSE = diff**2  
        acclist.append(MSE)
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k)
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] 
MeanErr = np.mean(error) 
MSEallcurrSVR = (MeanErr)   
rootSVR = np.sqrt(MSEallcurrSVR)  
outofsamp = RMAsqerror - rootSVR
RsqOOS = outofsamp # -0.00064012827358644192

# Save results
SVRRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
SVRRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//SVRRMSE.csv")

'''
SGD - LAGGED 3 DAYS + ADA BOOST REGRESSOR
'''
MSEallcurrSGD = np.zeros((1, 1)) 
MSEeachTimeallcurr= np.zeros(((data.shape[0]-(window+1)), 1)) 
coefs = []
X = data.iloc[ :-3, 1] #defines a dataframe with all variables for an industry
target = data.iloc[3: , 1] #define Y values - values to predict   
acclist = [] #a list of the squared error of all predictions made for an industry
for j in range(data.shape[0]): 
    try:
        Xtrain = X.iloc[j-window:j] 
        ytrain = target.iloc[j-window +1:j+1] 
        trainheadlines = []
        lin = SGDRegressor(random_state=12345)
        Xtrain = Xtrain.reshape((len(Xtrain), 1))
        ytrain = ytrain.reshape((len(ytrain), 1))         
        lin.fit(Xtrain,ytrain.ravel()) 
        predx = X.iloc[j+1]   
        predvalue = lin.predict(predx.reshape((1,-1)))
        diff = predvalue[0] - target.iloc[j + 2] 
        MSE = diff**2  
        acclist.append(MSE)
        coefs.append(lin.coef_)
    except:
        acclist.append('nan')
error = []
for k in acclist:
    if k != 'nan':
        error.append(k)
for l in range(len(error)):
    MSEeachTimeallcurr[l] = error[l] 
MeanErr = np.mean(error)  
MSEallcurrSGD= (MeanErr)    
rootSGD = np.sqrt(MSEallcurrSGD)  
outofsamp = RMAsqerror- rootSGD
RsqOOS = outofsamp # +0.00018681802748964083

# Save results
SGDRMSE = pd.DataFrame(data=MSEeachTimeallcurr)
SGDRMSE.to_csv("C://Users//artemis//Documents//BA_individual_report//SGDRMSE.csv")