# -*- coding: utf-8 -*-
"""
Created on Thu Jul 14 10:28:55 2017

@author: Andreas Georgopoulos

"""
from datetime import datetime
from tqdm import tqdm
import pandas as pd
import numpy as np
import time
import os

# Set Working Directory (change to yours)
os.chdir('/Users/macuser/Desktop/Research/Organic/organic_data')


"""
    ###########################################################################
    ######################### Correct Data Format #############################
    ###########################################################################
"""

"""
   Network Impressions --------------------------------------------------------
"""
# Import Initial Dataset
network_impressions = pd.read_csv('network_impressions.csv')

# Correct data format (each user two rows: every second row corresponds
#                        to buy_ID and so on features that are NA in first row)
buy_ID_index = network_impressions.columns.get_loc("buy_ID")
for row in tqdm(range(1,len(network_impressions),2)):
    # Extract user second row values and correct features indexed [buy_ID_index,-1]
    network_impressions.iloc[row-1, buy_ID_index:] = network_impressions.iloc[row,1:-(buy_ID_index-1)].values.tolist()
    
    time.sleep(0.01)
    
# Delete every second row from DataFrame
network_impressions.drop(range(1,len(network_impressions),2), inplace = True)
network_impressions = network_impressions.reset_index(drop = True)
# Save corrected dataframe
network_impressions.to_csv('network_impressions_corrected.csv', index = False)




"""
   Network Clicks -------------------------------------------------------------
"""
# Import Initial Dataset
network_clicks = pd.read_csv('network_click.csv')

# Correct Data Format
buy_ID_index = network_clicks.columns.get_loc("buy_ID")
number_of_features_to_get = len(network_clicks.iloc[:,buy_ID_index:].columns)
step = 1
for row in tqdm(range(0,len(network_clicks), step)):
    try:
        if(np.isnan(network_clicks.date.iloc[row]) == True):
            try:
                # Three lines for user
                if(np.isnan(network_clicks.date.iloc[row+1]) == True):
                    # Extract feature values of consecutive two rows
                    features_values = network_clicks.iloc[row,1:(buy_ID_index-1)].values.tolist() + network_clicks.iloc[row+1,1:-(buy_ID_index+2)].values.tolist()
                    step = 2
            except:
                # Two lines for user - Extract row features values
                features_values = network_clicks.iloc[row,1:-(buy_ID_index-1)].values.tolist()
            # Update correct values of features indexed [buy_ID_index,-1]
            network_clicks.iloc[row-1, buy_ID_index:] = features_values
    except:
        step = 1
        
    time.sleep(0.01)


# Delete every second row from DataFrame
network_clicks.drop(np.where(network_clicks.date.isnull())[0].tolist(), inplace = True)
network_clicks = network_clicks.reset_index(drop = True)
network_clicks.to_csv('network_clicks_corrected.csv', index = False)




"""
   Network Activities ---------------------------------------------------------
"""
# Import Initial Dataset
network_activities = pd.read_csv('network_activity.csv')

# Correct Data Format
buy_ID_index = network_activities.columns.get_loc("buy_ID")
number_of_features_to_get = len(network_activities.iloc[:,buy_ID_index:].columns)
step = 1
for row in tqdm(range(0,len(network_activities), step)):
    try:
        if(np.isnan(network_activities.date.iloc[row]) == True):
            try:
                # Three lines for user
                if(np.isnan(network_activities.date.iloc[row+1]) == True):
                    # Extract feature values of consecutive two rows
                    features_values = network_activities.iloc[row,1:(buy_ID_index-1)].values.tolist() + network_activities.iloc[row+1,1:-(buy_ID_index+2)].values.tolist()
                    step = 2
            except:
                # Two lines for user - Extract row features values
                features_values = network_activities.iloc[row,1:-(buy_ID_index-1)].values.tolist()
            # Update correct values of features indexed [buy_ID_index,-1]
            network_activities.iloc[row-1, buy_ID_index:] = features_values
    except:
        step = 1
        
    time.sleep(0.01)


# Delete every second row from DataFrame
network_activities.drop(np.where(network_activities.date.isnull())[0].tolist(), inplace = True)
network_activities = network_activities.reset_index(drop = True)

# Correct wrong entries
network_activities.loc[network_activities.is_conversion.isin(['TX','Texas']),'click_time'] = network_activities.loc[network_activities.is_conversion.isin(['TX','Texas']),'event_ID']
network_activities.loc[network_activities.is_conversion.isin(['TX','Texas']),'event_ID'] = 0.0
network_activities.loc[network_activities.is_conversion.isin(['TX','Texas']),'is_conversion'] = '0'
    
# Save corrected df
network_activities.to_csv('network_activities_corrected.csv', index = False)

    
    
    

"""
    ###########################################################################
    ############################ Preprocessing ################################
    ###########################################################################
"""
# Import Datasets with corrected formats
network_impressions = pd.read_csv('network_impressions_corrected.csv')
network_clicks      = pd.read_csv('network_clicks_corrected.csv')
network_activities  = pd.read_csv('network_activities_corrected.csv')


# Filter out 'bad' users (>1000 impressions, >500 activities, >30 clicks)
network_impressions = network_impressions[~network_impressions.user_id.isin(list(network_impressions.user_id.value_counts().reset_index(name="count").query("count > 1000")["index"]))]
network_clicks = network_clicks[~network_clicks.user_id.isin(list(network_clicks.user_id.value_counts().reset_index(name="count").query("count > 30")["index"]))]
network_activities  = network_activities[~network_activities.user_id.isin(list(network_activities.user_id.value_counts().reset_index(name="count").query("count > 500")["index"]))]


# Date & Time extraction of marketing intervention
network_impressions['Date'] = pd.to_datetime(network_impressions.date, format = "%d%b%Y:%H:%M:%S").dt.date
network_impressions['Time'] = pd.to_datetime(network_impressions.date, format = "%d%b%Y:%H:%M:%S").dt.time

# Time utc
network_impressions['Time_utc'] = network_impressions.time_utc_sec.apply(lambda x: datetime.fromtimestamp(x).strftime('%H:%M:%S'))

network_clicks['Date'] = pd.to_datetime(network_clicks.date, format = "%d%b%Y:%H:%M:%S").dt.date
network_clicks['Time'] = pd.to_datetime(network_clicks.date, format = "%d%b%Y:%H:%M:%S").dt.time

network_activities['Date'] = pd.to_datetime(network_activities.date, format = "%d%b%Y:%H:%M:%S").dt.date
network_activities['Time'] = pd.to_datetime(network_activities.date, format = "%d%b%Y:%H:%M:%S").dt.time
   
    
  


"""
    ###########################################################################
    ######################### Initial Findings ################################
    ###########################################################################
"""                  
 # User Descriptives --------------------------------------------------------------------                
# Number of impressions, clicks, activities and conversions for each user   
user_df = pd.DataFrame({'user_id':list(set(network_impressions.user_id))})

# Impressions
impressions_freq_df = network_impressions.user_id.value_counts().reset_index(name="No_Impressions")
impressions_freq_df.columns = ['user_id','No_Impressions']

# Clicks
clicks_freq_df = network_clicks.user_id.value_counts().reset_index(name="No_Clicks")
clicks_freq_df.columns = ['user_id','No_Clicks']

# Activities
activities_freq_df = network_activities.user_id.value_counts().reset_index(name="No_Activities")
activities_freq_df.columns = ['user_id','No_Activities']

# Conversions
# Multiple Conversions (activities) per user
conversions_freq_df = network_activities.loc[network_activities.is_conversion.astype(int) == 1,'user_id'].value_counts().reset_index(name="No_Conversions")
conversions_freq_df.columns = ['user_id','No_Conversions']

# Unique Conversions per click and user (one click might result in multiple conversions)
conversions_click_df = network_activities.loc[((network_activities.is_conversion.astype(int) == 1) & (network_activities.click_time.isnull() == False)), \
                                             ['user_id','click_time']].groupby(['user_id','click_time']).size().reset_index(name="No_Conversions_per_Click")
# Average number of conversion of each user per click
conversions_uniq_df = conversions_click_df.groupby('user_id')['No_Conversions_per_Click'].mean().reset_index(name="Average_No_Conversions_per_Click")
# Total number of Conversions triggered after a click
conversions_uniq_df = conversions_uniq_df.merge(conversions_click_df.groupby('user_id')['No_Conversions_per_Click'].sum().reset_index(name="No_Conversions_after_Click"), on = 'user_id', how = 'left')

# Unique total number of conversions of each user (if different clicks of same user resulted in any conversion)
conversions_uniq_df = conversions_uniq_df.merge(conversions_click_df.groupby('user_id').size().reset_index(name="No_Unique_Conversions_Unique_Clicks"), on = 'user_id', how = 'left')


# Merge with user df
user_df = user_df.merge(impressions_freq_df, on='user_id', how = "inner")
user_df = user_df.merge(clicks_freq_df, on='user_id', how = "left")
user_df = user_df.merge(activities_freq_df, on='user_id', how = "left") # If u want users with no impressions as well change to outer
user_df = user_df.merge(conversions_freq_df, on='user_id', how = "left")
user_df = user_df.merge(conversions_uniq_df, on='user_id', how = "left")


# Replace NaN with 0
user_df.fillna(0, inplace = True)

# Sort by user_id
user_df.sort_values(by = 'user_id', axis = 0, inplace=True)

# Click Through Rate
user_df['Click_Through_Rate'] = [round(user_df.No_Clicks.iloc[i] / user_df.No_Impressions.iloc[i],4) if user_df.No_Impressions.iloc[i] >0 else 0 for i in range(len(user_df))]

# Conversion Rate (No_Unique_Conversions_Unique_Clicks / No_Clicks)
user_df['Conversion_Rate'] = [round(user_df.No_Unique_Conversions_Unique_Clicks.iloc[i] / user_df.No_Clicks.iloc[i],4) if user_df.No_Clicks.iloc[i] >0 else None for i in range(len(user_df))]

# Save User Descriptive Dataset
user_df.to_csv('user_descriptives.csv', index = False)


# Dataframe plot (bining)
user_df_plot = user_df

bins_impr = [0, 5,15, 50,100, 250,750]
bins_names_impre = ['[1,5]','(5,15]','(15,50]','(50,100]','(100,250]','(250,750]']
bins_cl = [-1,0,1,2,3,4,10]
bins_names_cl = ['0','1','2','3','4','5+']

bins_act = [-1,5,15,30,50,100,500]
bins_names_act = ['[0,5]','(5,15]','(15,30]','(30,50]','(50,100]','(100,500]']

user_df_plot['Bins_Impressions'] = pd.cut(user_df.No_Impressions, bins_impr, labels=bins_names_impre)
user_df_plot['Bins_Clicks'] = pd.cut(user_df.No_Clicks, bins_cl, labels=bins_names_cl)
user_df_plot['Bins_Activities'] = pd.cut(user_df.No_Activities, bins_act, labels=bins_names_act)
# Save df to plor
user_df_plot.to_csv('user_df_plot.csv',index = False)




"""
    ###########################################################################
    ############### Matching Activities - Impressions #########################
    ###########################################################################
"""                  

# Impressions (converted: if clicked and then had a converted activity)

# Find users that have clicks but also recorded impressions
users_impres_clicks = list(set(network_impressions.user_id) & set(network_clicks.user_id))
network_clicks_impr = network_clicks[network_clicks.user_id.isin(users_impres_clicks)]

# Assign each recorded click to last impression (based on time) for user_ids in both clicks and impressions:    
network_impressions['click_conversion'] = 0   
network_impressions['click_datetime'] = 0            
for i in tqdm(network_clicks_impr.index.tolist()):
    # Find last impression before user's click and assign click conversion to impression
    network_impressions.loc[ network_impressions[(network_impressions.user_id == network_clicks_impr.loc[i, 'user_id']) & (network_impressions.Date == network_clicks_impr.loc[i, 'Date'])
                & (network_impressions.Time <= network_clicks_impr.loc[i, 'Time'])].tail(1).index, 'click_conversion'] = 1
    # Extract click time (for later use)
    network_impressions.loc[ network_impressions[(network_impressions.user_id == network_clicks_impr.loc[i, 'user_id']) & (network_impressions.Date == network_clicks_impr.loc[i, 'Date'])
                & (network_impressions.Time <= network_clicks_impr.loc[i, 'Time'])].tail(1).index, 'click_datetime'] = network_clicks_impr.loc[i,'date']
    time.sleep(0.01)


# Activities after a click -------------------------------------
# For each click find if resulted in any conversion (activities) and add to corresponding impression that triggered the click
network_act_cl = network_activities.loc[((network_activities.click_time.isnull() == False)), ['user_id','click_time','Date','Time','is_conversion','event_ID']].groupby(['user_id','click_time'])['is_conversion'].sum().reset_index(name="activity_conversion_click")
network_act_cl.activity_conversion_click = [0 if x == 0 else 1 for x in network_act_cl.activity_conversion_click]
network_act_cl.columns = ['user_id','click_datetime','activity_conversion_click']                           
# Merge with corresponding impression based on click_date and user_id
network_impressions = network_impressions.merge(network_act_cl, on = ['user_id','click_datetime'], how = 'left')

# If NA then assume no conversion
network_impressions.activity_conversion_click.fillna(0, inplace = True)


# Activities without a click ------------------------------------
network_impressions['activity_conversion_no_click'] = 0            

# Find activities that were not triggered by a click and resulted in conversion
network_act_no_click = network_activities.loc[((network_activities.click_time.isnull() == True) & (network_activities.is_conversion.astype(int) == 1)), ['user_id','Date','Time','is_conversion','event_ID']]
# Users with recorded activities and impressions without any recorded click
users_act_no_click_impre = list(set(network_act_no_click.user_id) & set(network_impressions.user_id))


for user in tqdm(users_act_no_click_impre):
    impr = network_impressions.loc[network_impressions.user_id == user, ['Date', 'Time']]
    act = network_act_no_click.loc[network_act_no_click.user_id == user,['Date', 'Time']]
    act['hour'] = act.Time.apply(lambda x: x.hour)
    # If min date of impressions after max day of activities, pass (we followed the user after an activity)
    if(min(impr.Date) > max(act.Date)):
        pass
    else:
        # Try to attach a conversion to an impression based on date
        for j in list(set(act.Date)):
            # Find min and max time of activities at each date
            min_time_act = min(act.loc[act.Date == j, 'Time'])
            max_time_act = max(act.loc[act.Date == j, 'Time'])
            # If in one day multiple activities on different point of times
            if (max_time_act.hour - min_time_act.hour > 2):
                # Assign first activity to an impression
                try: 
                    # same date
                    network_impressions.loc[impr.loc[(impr.Date == j) & (impr.Time <= min_time_act)].tail(1).index, 'activity_conversion_no_click'] = 1
                except:
                    # Assign to last impression in a time window of 7 days
                    try:
                        # Find most current impression and assign activity of date
                        network_impressions.loc[impr.loc[(impr.Date < j) & ((impr.Date - j).dt.days <= 7)].tail(1).index, 'activity_conversion_no_click'] = 1
                    except:
                        pass
                    
                # Assign second activity (later on during day)
                # Find min time of second activity/(series of activities) at same date
                min_time_act_2 = min(act.loc[(act.Date == j) & (max_time_act.hour - act.hour < 1), 'Time'])
                try: 
                    # same date
                    network_impressions.loc[impr.loc[(impr.Date == j) & (impr.Time <= min_time_act_2)].tail(1).index, 'activity_conversion_no_click'] = 1
                except:
                    # Assign to last impression in a time window of 7 days
                    try:
                        # Find most current impression and assign activity of date
                        network_impressions.loc[impr.loc[(impr.Date < j) & ((impr.Date - j).dt.days <= 7)].tail(1).index, 'activity_conversion_no_click'] = 1
                    except:
                        pass
      
            # Activity (or series of activities at one time during day)                
            else:
                # Assign first activity to an impression only 
                try: 
                    # same date
                    network_impressions.loc[impr.loc[(impr.Date == j) & (impr.Time <= min_time_act)].tail(1).index, 'activity_conversion_no_click'] = 1
                except:
                    # Assign to last impression in a time window of 7 days
                    try:
                        # Find most current impression and assign activity of date
                        network_impressions.loc[impr.loc[(impr.Date < j) & ((impr.Date - j).dt.days <= 7)].tail(1).index, 'activity_conversion_no_click'] = 1
                    except:
                        pass
                       
    time.sleep(0.01)
            
    
# Much impressions that ended to a conversion with or without a click
network_impressions['activity_conversion'] = network_impressions.activity_conversion_no_click + network_impressions.activity_conversion_click
network_impressions.loc[network_impressions.activity_conversion >1, 'activity_conversion'] = 1
                       
# Save Dataframe for Attribution Modelling
network_impressions.to_csv('network_impressions_modeling.csv', index = False)


