'''
Find Route Set with 0, 1, 2, 3, 4 transfers

'''
import pandas as pd
import numpy as np
from GraphHelper import getInfoOnPath, k_shortest_paths, isLogicalSamePath
from HelperFunctions import splitTripOnTrainTrips, fixStationName
import networkx as nx

def findChangeThresholds(travel_tours, stationsWithLines, G_no_changes, G_no_walks):
    train_tours = travel_tours.sample(frac=0.7,random_state=200)
    train_tours = train_tours.reset_index(drop=True)
    test_tours = travel_tours.drop(train_tours.index)
    test_tours = test_tours.reset_index(drop=True)
    
    #def predict_new_path():
    #for row in range(1, len(train_tours)):
    thresholds = [0, 0.01, 0.03, 0.05, 0.07, 0.09, 0.1, 0.2, 0.5, 1]
    #thresholds = [0.19, 0.21, 0.23, 0.25]
    #thresholds = [0.05]
    prediction_accuracy = {}
    for transfer_threshold in thresholds:
        print ("Working on the {} transfer threshold".format(transfer_threshold))
        allTripsTaken, splittedTrips, allUsers = getRealTrips((train_tours[0:2000]), stationsWithLines, G_no_changes)
    
        correct_prediction = 0
        total_passengers = 0
        route_id = 0
        index = 0
        for trip, flow in allTripsTaken:
            #Real route: trip
            if index % 100 == 0:
                pass
            index += 1
            route_id = route_id + 1
            total_flow = flow[-1]
            total_passengers = total_passengers + total_flow
            
            #Predicted route:            
            from_stat = trip[0]
            to_stat = trip[-1]
    
            df2 = pd.DataFrame()
            for path in k_shortest_paths(G_no_walks, from_stat, to_stat, 10, "Running_Time"):   
                time1, distance1, changes1, avgFlow1 = getInfoOnPath(path, G_no_walks)
                df2 = df2.append({'route_id': route_id, 'time': time1, 'changes': changes1, 'path': path}, ignore_index=True)
            df2 = df2.sort_values(['route_id', 'changes', 'time'], ascending=[True, True, True]).reset_index(drop=True)         
            df3 = df2.groupby('changes').first().reset_index()
            
            for row in range(len(df3)):
                changes = int(df3.loc[row, "changes"])
                time = df3.loc[row, "time"]
                threshold = df3.loc[df3['changes'] == (min(df3['changes'])), "time"][0] * transfer_threshold
                df3.loc[row, "time"] = time+(threshold * changes)
            
            path_chosen1 = df3.sort_values(['time'], ascending = True).reset_index()
        
            if isLogicalSamePath(path_chosen1.loc[0, 'path'], trip):
                correct_prediction = correct_prediction + total_flow
    
            else:
                if False:
                    print ("Chosen path:")
                    print (chosen_path)
                    print ("Trip:")
                    print (trip)
                    totalPath2Time, a, totalPath2Changes, b = getInfoOnPath(totalPath, G_no_walks)
                    print ("Chosen path changes: {} time:{}, Trip changes:{} time:{} ".format(path_chosen1.loc[0,'changes'], path_chosen1.loc[0,'time'], totalPath2Changes, totalPath2Time))
                    print ("")
                    pass
        normalisedCorrectPredictions = correct_prediction/float(total_passengers)
        prediction_accuracy[transfer_threshold] = normalisedCorrectPredictions
        print("correct_prediction: {} out of {} ({:.2f} %) with threshold {}".format(correct_prediction, total_passengers, normalisedCorrectPredictions*100, transfer_threshold))
    
                
def getRealTrips(travel_tours, stationsWithLines, G_no_changes):
    allTripsTaken = []
    splittedTrips = 0
    totalUsers = 0
    AMUsers = 0
    earlyUsers = 0
    middayUsers = 0
    PMUsers = 0
    eveningUsers = 0
    lateUsers = 0
    for row in range(1, len(travel_tours)):
        changeStationsInTrip = []
        from_stat = travel_tours.loc[row, 'from_stat'].strip()
        from_stat = fixStationName(from_stat)
        to_stat = travel_tours.loc[row, 'to_stat'].strip()
        to_stat = fixStationName(to_stat)
        via_stat = travel_tours.loc[row, 'Via'].strip()
        via_stat = fixStationName(via_stat)
        via_stat2 = travel_tours.loc[row, 'Via2'].strip()
        via_stat2 = fixStationName(via_stat2)
        via_stat3 = travel_tours.loc[row, 'Via3'].strip()
        via_stat3 = fixStationName(via_stat3)
        via_stat4 = travel_tours.loc[row, 'Via4'].strip()
        via_stat4 = fixStationName(via_stat4)
        
        total_flow = int(travel_tours.loc[row, 'total_flow'])
        early_flow = int(travel_tours.loc[row, 'Early'])
        am_flow = int(travel_tours.loc[row, 'AM peak'])
        midday_flow = int(travel_tours.loc[row, 'Midday'])
        pm_flow = int(travel_tours.loc[row, 'PM peak'])
        evening_flow = int(travel_tours.loc[row, 'Evening'])
        late_flow = int(travel_tours.loc[row, 'Late'])

        flows = (early_flow, am_flow, midday_flow, pm_flow, evening_flow, late_flow, total_flow)
        changeStationsInTrip.append(from_stat)
        if via_stat:
            changeStationsInTrip.append(via_stat) 
        if via_stat2:
            changeStationsInTrip.append(via_stat2)
        if via_stat3:
            changeStationsInTrip.append(via_stat3)
        if via_stat4:
            changeStationsInTrip.append(via_stat4)
        changeStationsInTrip.append(to_stat)
        subTrips = splitTripOnTrainTrips(changeStationsInTrip, stationsWithLines)
        if len(subTrips) > 1:
            splittedTrips = splittedTrips + 1
        for changeStationsInTrip in subTrips:
            totalPath = [from_stat]
            index = 0

            for _ in range(0, int(len(changeStationsInTrip)/2)):
                a_plat = changeStationsInTrip[index]
                b_plat = changeStationsInTrip[index+1]
                index = index + 2
                path = nx.shortest_path(G_no_changes, a_plat, b_plat)
                totalPath = totalPath + path
                totalPath.append(path[-1].split(":")[0])
                if len(changeStationsInTrip) > 1:
                    allTripsTaken.append((totalPath, flows))
                    totalUsers = totalUsers + total_flow
                    AMUsers = AMUsers + am_flow
                    earlyUsers = earlyUsers + early_flow
                    middayUsers = middayUsers + midday_flow
                    PMUsers = PMUsers + pm_flow
                    eveningUsers = eveningUsers + evening_flow
                    lateUsers = lateUsers + late_flow
    allUsers = (totalUsers, AMUsers, earlyUsers, middayUsers, PMUsers, eveningUsers, lateUsers)
    return allTripsTaken, splittedTrips, allUsers

def get_optimal_route(from_stat, to_stat, G):
    df2 = pd.DataFrame()
    for path in k_shortest_paths(G, from_stat, to_stat, 10, "Running_Time"):   
        time1, distance1, changes1, avgFlow1 = getInfoOnPath(path, G)
        df2 = df2.append({'time': time1, 'changes': changes1, 'path': path}, ignore_index=True)
    df2 = df2.sort_values(['changes', 'time'], ascending=[True, True]).reset_index(drop=True)         
    df3 = df2.groupby('changes').first().reset_index()
    
    for row in range(len(df3)):
        changes = int(df3.loc[row, "changes"])
        time = df3.loc[row, "time"]
        threshold = df3.loc[df3['changes'] == (min(df3['changes'])), "time"][0] * 0.05
        df3.loc[row, "time"] = time + (0.05 * changes)
    
    path_chosen = df3.sort_values(['time'], ascending = True).reset_index()
    path_chosen = path_chosen.loc[0, 'path']
    return path_chosen
    