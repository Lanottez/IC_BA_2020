import networkx as nx
from itertools import islice
from HelperFunctions import splitTripOnTrainTrips, fixStationName, distanceBetweenCoordinates
import random

def ifMissingEdgeInPath(path, A, B):
	for i in range(1, len(path)):
		s = path[i-1]
		t = path[i]
		if s == A and t == B:
			return True
	return False

def removeWalksFromGraph(G):
    G_no_walks = G.copy()
    for edge in G.edges():
        u, v = edge
        edge_data = G_no_walks.get_edge_data(u, v)
        if edge_data["Line"] == "Walk":
            G_no_walks.remove_edge(u, v)
    return G_no_walks

def makeUndirected(G):
    G_undir = nx.Graph()
    for edge in G.edges():
        u, v = edge
        edge_data = G.get_edge_data(u, v)
        if (u, v) not in G_undir.edges() and (v, u) not in G_undir.edges():
            G_undir.add_edge(u, v, edge_data)
        else:
            edge_data_undir = G_undir.get_edge_data(u, v)
            for data in edge_data_undir:
                if "flow" in data:
                    G_undir[u][v][data] = G_undir[u][v][data] + edge_data[data]
    return G_undir

'''
K-Shortest Paths
'''
def k_shortest_paths(G, source, target, k, weight=None):
	topKPaths = []
	bestPaths = list(islice(nx.shortest_simple_paths(G, source, target, weight=weight), 10))
	topKPaths.append(bestPaths[0])
	i = 1
	while len(topKPaths) < k and i < len(bestPaths):
		isLogicalDifferent = True
		for path in topKPaths:
			if isLogicalSamePath(path, bestPaths[i]):
				isLogicalDifferent = False
		if isLogicalDifferent:
			topKPaths.append(bestPaths[i])
		i += 1
	return topKPaths

def _getNodesFromPath(path):
	_set = set()
	for node in path:
		if ":" in node:
			node = node.split(":")[0]
		_set.add(node)
	return _set
def isLogicalSamePath(path1, path2):
	if path1 == None or path2 == None:
     		return False
	set1 = _getNodesFromPath(path1)
	set2 = _getNodesFromPath(path2)
	return set1 == set2
def getInfoFromEdge(path, index, G):
	a = path[index-1]
	b = path[index]
	lineA, lineB = None, None
	if ":" in a:
		lineA = a.split(":")[1]
	if ":" in b:
		lineB = b.split(":")[1]
	edge_data = G.get_edge_data(a, b)
	return a, b, lineA, lineB, edge_data
def getInfoOnPath(path, G):
	time = 0
	for i in range(1, len(path)):
		a, b, lineA, lineB, edge_data = getInfoFromEdge(path, i, G)
		if edge_data != None:
			time += edge_data["Running_Time"]
	path = [x for x in path if ":" in x]
	distance = 0
	changes = 0
	totFlow = 0
	numFlows = 0
	avgFlow = 0
	for i in range(1, len(path)):
		a, b, lineA, lineB, edge_data = getInfoFromEdge(path, i, G)
		if lineA != lineB:
			changes += 1
		if edge_data != None:
			distance += edge_data["Distance"]
			totFlow += edge_data["total_flow"]
			numFlows += 1
	if numFlows != 0:
		avgFlow = totFlow/float(numFlows)
	return time, distance, changes, avgFlow

def generate_G_no_platforms(time_table_final2, dict_geo):
    G_no_platforms = nx.DiGraph()
    for row in range(len(time_table_final2)):
        from_station = time_table_final2.loc[row,'Station1_name'].split(":")[0]
        to_station = time_table_final2.loc[row,'Station2_name'].split(":")[0]
        lat1 = time_table_final2.loc[row,'lat1']
        lng1 = time_table_final2.loc[row,'lon1']
        lat2 = time_table_final2.loc[row,'lat2']
        lng2 = time_table_final2.loc[row,'lon2']
        flow = time_table_final2.loc[row,'total_flow']
        dist3 = distanceBetweenCoordinates(lat1, lng1, lat2, lng2)
        lat1 = dict_geo[from_station][0]
        lng1 = dict_geo[from_station][1]
        lat2 = dict_geo[to_station][0]
        lng2 = dict_geo[to_station][1]
        dist = time_table_final2.loc[row,'Distance']
        dist2 = distanceBetweenCoordinates(lat1, lng1, lat2, lng2)
        if dist3 > dist:
            dist = dist3*1.3
        G_no_platforms.add_edge(from_station, to_station, {"Distance": dist, "total_flow": flow})
    return G_no_platforms
    
def getAffectedUsers(travel_tours, stationsWithLines, G_no_changes, removeFrom, removeTo, numTrips=None):
	allTripsTaken = []
	affectedTrips = []
	totalAffectedUsers = 0
	AMAffectedUsers = 0
	earlyAffectedUsers = 0
	middayAffectedUsers = 0
	PMAffectedUsers = 0
	eveningAffectedUsers = 0
	lateAffectedUsers = 0
	splittedTrips = 0
	totalUsers = 0
	AMUsers = 0
	earlyUsers = 0
	middayUsers = 0
	PMUsers = 0
	eveningUsers = 0
	lateUsers = 0
	if numTrips == None:
		rowIndices = range(1, len(travel_tours))
	else:
		rowIndices = random.sample(range(1, len(travel_tours)), numTrips)
	for row in rowIndices:
		changeStationsInTrip = []
		from_stat = travel_tours.loc[row, 'from_stat'].strip()
		from_stat = fixStationName(from_stat)
		to_stat = travel_tours.loc[row, 'to_stat'].strip()
		to_stat = fixStationName(to_stat)
		via_stat = travel_tours.loc[row, 'Via'].strip()
		via_stat = fixStationName(via_stat)
		via_stat2 = travel_tours.loc[row, 'Via2'].strip()
		via_stat3 = travel_tours.loc[row, 'Via3'].strip()
		via_stat4 = travel_tours.loc[row, 'Via4'].strip()
		total_flow = int(travel_tours.loc[row, 'total_flow'])
		early_flow = int(travel_tours.loc[row, 'Early'])
		am_flow = int(travel_tours.loc[row, 'AM peak'])
		midday_flow = int(travel_tours.loc[row, 'Midday'])
		pm_flow = int(travel_tours.loc[row, 'PM peak'])
		evening_flow = int(travel_tours.loc[row, 'Evening'])
		late_flow = int(travel_tours.loc[row, 'Late'])

		flows = (early_flow, am_flow, midday_flow, pm_flow, evening_flow, late_flow, total_flow)
		changeStationsInTrip.append(from_stat)
		if via_stat:
			changeStationsInTrip.append(via_stat) 
		if via_stat2:
			changeStationsInTrip.append(via_stat2)
		if via_stat3:
			changeStationsInTrip.append(via_stat3)
		if via_stat4:
			changeStationsInTrip.append(via_stat4)
		changeStationsInTrip.append(to_stat)

		subTrips = splitTripOnTrainTrips(changeStationsInTrip, stationsWithLines)
		if len(subTrips) > 1:
			splittedTrips = splittedTrips + 1
		for changeStationsInTrip in subTrips:
			tripIsAffected = False
			totalPath = [from_stat]
			index = 0
			for _ in range(0, int(len(changeStationsInTrip)/2)):
				a_plat = changeStationsInTrip[index]
				b_plat = changeStationsInTrip[index+1]
				index = index + 2
				path = nx.shortest_path(G_no_changes, a_plat, b_plat)
				totalPath = totalPath + path
				totalPath.append(path[-1].split(":")[0])
				if ifMissingEdgeInPath(path, removeFrom, removeTo):
					tripIsAffected = True
			if len(changeStationsInTrip) > 1:
				allTripsTaken.append((totalPath, flows))
				totalUsers = totalUsers + total_flow
				AMUsers = AMUsers + am_flow
				earlyUsers = earlyUsers + early_flow
				middayUsers = middayUsers + midday_flow
				PMUsers = PMUsers + pm_flow
				eveningUsers = eveningUsers + evening_flow
				lateUsers = lateUsers + late_flow
			if tripIsAffected:
				affectedTrips.append((totalPath, flows))
				totalAffectedUsers = totalAffectedUsers + total_flow
				AMAffectedUsers = AMAffectedUsers + am_flow
				earlyAffectedUsers = earlyAffectedUsers + early_flow
				middayAffectedUsers = middayAffectedUsers + midday_flow
				PMAffectedUsers = PMAffectedUsers + pm_flow
				eveningAffectedUsers = eveningAffectedUsers + evening_flow
				lateAffectedUsers = lateAffectedUsers + late_flow
	affectedUsers = (totalAffectedUsers, AMAffectedUsers, earlyAffectedUsers, middayAffectedUsers, PMAffectedUsers, eveningAffectedUsers, lateAffectedUsers)
	allUsers = (totalUsers, AMUsers, earlyUsers, middayUsers, PMUsers, eveningUsers, lateUsers)
	return affectedTrips, allTripsTaken, splittedTrips, affectedUsers, allUsers