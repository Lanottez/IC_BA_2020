import networkx as nx
import pandas as pd
from HelperFunctions import global_efficiency, distanceBetweenCoordinates, fixStationName
from GraphHelper import k_shortest_paths, getInfoOnPath, isLogicalSamePath
import numpy as np
from collections import Counter

def getAvgEdgeBetweennessCentrality(G):
    ''' Avg Edge Betweenness Centrality '''
    betw_cent = nx.edge_betweenness_centrality(G, normalized=True, weight='Running_Time')
    sum_value = 0
    count = 0
    max_bc = max(list(betw_cent.values()))
    max_key = set()
    for key, value in betw_cent.items():
        if value != 0:
            count = count + 1
            sum_value = sum_value + value
        if value == max_bc:        
            max_key.add(key)
    print ("max_key: {}, max_betw: {}".format(max_key, max_bc))
    avg_between = sum_value/count
    return avg_between

def combination_betweenness_weight(G):
    betw_cent = nx.edge_betweenness_centrality(G, normalized=True, weight='Running_Time')
    combined_values = []
    max_weight = 0
    max_betweenes = 0
    max_weight_edge = None
    max_betweenes_edge = None
    for key, value in betw_cent.items():
        a = key[0]
        b = key[1]
        weight = G.get_edge_data(a, b)['total_flow']
        if weight > max_weight:
            max_weight = weight
            max_weight_edge = (a, b)
        if value > max_betweenes:
            max_betweenes = value
            max_betweenes_edge = (a, b)
        avg_weight = 50252
        proportion_w = (weight-avg_weight)/avg_weight
        if proportion_w > float(-1):
            
            combined_value = (1 + proportion_w) * value
            combined_values.append((a, b, combined_value))
        else:
            combined_value = 0
            combined_values.append((a, b, combined_value))
    max_combined = 0
    max_combined_edge = ""
    for x,y,z in combined_values:
        if z > max_combined:
            max_combined_edge = (str(x), str(y))
            max_combined = z
        
    return max_combined, max_weight, max_betweenes, max_combined_edge, max_weight_edge, max_betweenes_edge

def getAvgClosenessCentrality(G):
    ''' Avg Closeness Centrality '''
    close_cent = nx.closeness_centrality(G, distance='Distance', normalized=True)
    sum_value = 0
    count = 0
    for key, value in close_cent.items():
        if value != 0:
            count = count + 1
            sum_value = sum_value + value    
    avg_closeness = sum_value/float(count)
    return avg_closeness

def getAvgClusteringCoeffisient(G):
    ''' Avg Clustering Coeffisient '''
    avg_clustering = nx.average_clustering(G)
    return avg_clustering

def getGraphEfficiency(G, dict_geo):
    ''' Efficiency '''
    stations = {}
    for key in dict_geo:
        sKey = key
        if ":" in sKey:
            sKey = sKey.split(":")[0]
        stations[sKey] = key

    station1 = []
    station2 = []
    dist_e = []
    for stat1 in stations:
        for stat2 in stations:
            if stat1 != stat2:
                key1 = stations[stat1]
                key2 = stations[stat2]
                station1.append(key1)
                station2.append(key2)
                lat1 = dict_geo[key1][0]
                lng1 = dict_geo[key1][1]
                lat2 = dict_geo[key2][0]
                lng2 = dict_geo[key2][1]
                dist = distanceBetweenCoordinates(lat1, lng1, lat2, lng2)
                dist_e.append(dist)

    full_network = pd.DataFrame(np.column_stack([station1, station2, dist_e]), 
                                   columns=['station1', 'station2', 'Distance'])   
    full_network['Distance'] = pd.to_numeric(full_network['Distance'])

    G_full = nx.from_pandas_dataframe(full_network, 'station1', 'station2', 'Distance')
    print ("G_full nodes:", len(G_full.nodes()))
    print ("G_full edges:", len(G_full.edges()))
    print ("G nodes:", len(G.nodes()))
    avg_efficiency = global_efficiency(G, 'Distance', isComplete=False)
    print ("avg_efficiency:", avg_efficiency)
    ideal_efficiency = global_efficiency(G_full, 'Distance', isComplete=False)
    print ("ideal_efficiency:", ideal_efficiency)
    norm_efficiency = avg_efficiency/float(ideal_efficiency)
    return G_full, norm_efficiency

def getHowManyUsesShortestPath(allTripsTaken, G_no_walks, G, travel_tours):
    total_flow_01_shortest_path = 0
    total_flow_02_shortest_path = 0
    total_flow_03_shortest_path = 0
    total_flow_no_shortest_path = 0
    am_flow_01_shortest_path = 0
    am_flow_02_shortest_path = 0
    am_flow_03_shortest_path = 0
    am_flow_no_shortest_path = 0
    earlycount = 0
    middaycount = 0
    pm_flow_01_shortest_path = 0
    pm_flow_02_shortest_path = 0
    pm_flow_03_shortest_path = 0
    pm_flow_no_shortest_path = 0
    eveningcount = 0
    latecount = 0
    compare_shortest_chosen = []
    a = 0
    b = 0
    c = 0
    d = 0
    timeDiff = []
    distDiff = []
    changeDiff = []
    avgFlowDiff = []
    diffStats = []

    index = 1
    for trip, flows in allTripsTaken:
        if index % 100 == 0:
            print ("{} av {} done".format(index, len(allTripsTaken)))
        index += 1
        fromStation2 = fixStationName(trip[0])
        toStation2 = fixStationName(trip[-1])
        short_list = k_shortest_paths(G_no_walks, fromStation2, toStation2, 3, "Running_Time")
        short_path1 = short_list[0]
        short_path2, short_path3 = None, None
        time_short_path1, distance_short_path1, changes_short_path1, avgFlow_short_path1 = getInfoOnPath(short_path1, G)
        if len(short_list) > 1:
            short_path2 = short_list[1]
            time_short_path2, distance_short_path2, changes_short_path2, avgFlow_short_path2 = getInfoOnPath(short_path2, G)
        if len(short_list) > 2:
            short_path3 = short_list[2]
            time_short_path3, distance_short_path3, changes_short_path3, avgFlow_short_path3 = getInfoOnPath(short_path3, G)
        time_trip, distance_trip, changes_trip, avgFlow_trip = getInfoOnPath(trip, G)
        early_flow, am_flow, midday_flow, pm_flow, evening_flow, late_flow, total_flow = flows
        if isLogicalSamePath(short_path1, trip):
            total_flow_01_shortest_path = total_flow_01_shortest_path + total_flow
            am_flow_01_shortest_path = am_flow_01_shortest_path + am_flow
            pm_flow_01_shortest_path = pm_flow_01_shortest_path + pm_flow
            a = a + 1
            #AMcount = AMcount + AM_use
            #PMcount = PMcount + PM_use
            #earlycount = earlycount + early_use
            #middaycount = middaycount + midday_use
            #eveningcount = eveningcount + evening_use
            #latecount = latecount + late_use
        else:
            time_tripShortest, distance_tripShortest, changes_tripShortest, avgFlow_tripShortest = getInfoOnPath(short_path1, G)
            _dict = {}
            _dict["time"] = (time_trip, time_tripShortest)
            _dict["distance"] = (distance_trip, distance_tripShortest)
            _dict["changes"] = (changes_trip, changes_tripShortest)
            _dict["avgFlow"] = (avgFlow_trip, avgFlow_tripShortest)
            diffStats.append(_dict)
            timeDiff.append(time_trip-time_tripShortest)
            distDiff.append(distance_trip-distance_tripShortest)
            changeDiff.append(changes_trip-changes_tripShortest)
            avgFlowDiff.append(avgFlow_trip-avgFlow_tripShortest)
            if isLogicalSamePath(short_path2, trip):
                total_flow_02_shortest_path = total_flow_02_shortest_path + total_flow
                am_flow_02_shortest_path = am_flow_02_shortest_path + am_flow
                pm_flow_02_shortest_path = pm_flow_02_shortest_path + pm_flow
                b = b + 1
                #AMcount2 = AMcount2 + AM_use
            elif isLogicalSamePath(short_path3, trip):
                total_flow_03_shortest_path = total_flow_03_shortest_path + total_flow
                am_flow_03_shortest_path = am_flow_03_shortest_path + am_flow
                pm_flow_03_shortest_path = pm_flow_03_shortest_path + pm_flow
                c = c + 1
                #AMcount3 = AMcount3 + AM_use
            else:
                total_flow_no_shortest_path = total_flow_no_shortest_path + total_flow
                am_flow_no_shortest_path = am_flow_no_shortest_path + am_flow
                pm_flow_no_shortest_path = pm_flow_no_shortest_path + pm_flow
                d = d + 1
                continue
                #print "Trip: {}".format(trip)
                print ("Trip Stats:")
                print ("time: {}, distance: {}, changes: {}, avgFlow: {}".format(time_trip, distance_trip, changes_trip, avgFlow_trip))
                #print ("short_path1: {}".format(short_path1))
                print ("short_path1 Stats:")
                print ("time: {}, distance: {}, changes: {}, avgFlow: {}".format(time_short_path1, distance_short_path1, changes_short_path1, avgFlow_short_path1))
                #print ("short_path2: {}".format(short_path2))
                print ("short_path2 Stats:")
                print ("time: {}, distance: {}, changes: {}, avgFlow: {}".format(time_short_path2, distance_short_path2, changes_short_path2, avgFlow_short_path2))
                #print ("short_path3: {}".format(short_path3))
                print ("short_path3 Stats:")
                print ("time: {}, distance: {}, changes: {}, avgFlow: {}".format(time_short_path3, distance_short_path3, changes_short_path3, avgFlow_short_path3))
                print ("")
        if (time_short_path1-time_trip)>0.01:
            print ("Trip: {}".format(trip))
            print ("Trip Stats:")
            print ("time: {}, distance: {}, changes: {}, avgFlow: {}".format(time_trip, distance_trip, changes_trip, avgFlow_trip))
            print ("short_path1: {}".format(short_path1))
            print ("short_path1 Stats:")
            print ("time: {}, distance: {}, changes: {}, avgFlow: {}".format(time_short_path1, distance_short_path1, changes_short_path1, avgFlow_short_path1))
            print ("")

    #percentage of people choosing shortest path:    
    travel_tours['total_flow'] = travel_tours['total_flow'].apply(int)
    travel_tours['AM peak'] = travel_tours['AM peak'].apply(int)
    
    print ("total_flow_01: {}, total_flow_02: {}, total_flow_03: {}, total_flow_no: {}".format(total_flow_01_shortest_path, total_flow_02_shortest_path, total_flow_03_shortest_path, total_flow_no_shortest_path))
    print ("am_flow_01: {}, am_flow_02: {}, am_flow_03: {}, am_flow_no: {}".format(am_flow_01_shortest_path, am_flow_02_shortest_path, am_flow_03_shortest_path, am_flow_no_shortest_path))
    print ("pm_flow_01: {}, pm_flow_02: {}, pm_flow_03: {}, pm_flow_no: {}".format(pm_flow_01_shortest_path, pm_flow_02_shortest_path, pm_flow_03_shortest_path, pm_flow_no_shortest_path))
    
    print (100*total_flow_01_shortest_path/float(sum(travel_tours['total_flow'])))
    print (100*total_flow_02_shortest_path/float(sum(travel_tours['total_flow'])))
    print (100*total_flow_03_shortest_path/float(sum(travel_tours['total_flow'])))
    
    print ("Takes shortest path in AM peak: {:.2f} %".format(100*am_flow_01_shortest_path/float(am_flow_01_shortest_path+am_flow_02_shortest_path+am_flow_03_shortest_path+ am_flow_no_shortest_path)))
    print ("Takes shortest path in PM peak: {:.2f} %".format(100*pm_flow_01_shortest_path/float(pm_flow_01_shortest_path + pm_flow_02_shortest_path + pm_flow_03_shortest_path + pm_flow_no_shortest_path)))
    print ("Takes shortest path in total  : {:.2f} %".format(100*total_flow_01_shortest_path/float(total_flow_01_shortest_path + total_flow_02_shortest_path + total_flow_03_shortest_path + total_flow_no_shortest_path)))
    
    timeDiff2 = np.array(timeDiff)
    distDiff2 = np.array(distDiff)
    avgFlowDiff2 = np.array(avgFlowDiff)
    print ("Diff Time:     avarage: {:.2f}, median: {:.2f}, std: {:.2f}".format(np.mean(timeDiff2, axis=0), np.median(timeDiff2, axis=0), np.std(timeDiff2, axis=0)))
    print ("Diff distance: avarage: {:.2f}, median: {:.2f}, std: {:.2f}".format(np.mean(distDiff2, axis=0), np.median(distDiff2, axis=0), np.std(distDiff2, axis=0)))
    print ("Diff AvgFlow:  avarage: {:.2f}, median: {:.2f}, std: {:.2f}".format(np.mean(avgFlowDiff2, axis=0), np.median(avgFlowDiff2, axis=0), np.std(avgFlowDiff2, axis=0)))
    print ("Diff changes: {}".format(Counter(changeDiff)))
    
        
    