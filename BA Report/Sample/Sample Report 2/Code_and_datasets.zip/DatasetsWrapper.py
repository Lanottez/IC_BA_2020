import pandas as pd
import numpy as np
from HelperFunctions import getStationFromNode, getEdgeName, fixStationName

#Read all datasets
def readDatasets(station_location, interChangeTimes):
    basic_path = 'datasets/'
    pass_table = pd.read_csv(basic_path + 'StationPassengerLinkFlows.csv')
    pass_info = pd.read_csv(basic_path + 'StationNodesDescription.csv')
    pass_info['Node'] = pass_info['Node'].astype(str)

    line_load = pd.read_csv(basic_path + 'line_netork_edit.csv')
    station_in = pd.read_csv(basic_path + 'En16week.csv', skiprows = 6)
    station_in = clean_station_in(station_in)
    station_out = pd.read_csv(basic_path + 'Ex16week.csv', skiprows = 6)
    station_out = clean_station_out(station_out)
    od_data = pd.read_csv(basic_path + 'od_data(copy).csv', skiprows = 2)
    od_data = clean_od(od_data)
    travel_tours = pd.read_csv(basic_path + 'Route_choice.csv', skiprows = 2)
    travel_tours = travel_tours.drop(travel_tours.index[[0]])
    travel_tours.rename(columns={'Unnamed: 1':'from_stat'}, inplace=True)
    travel_tours.rename(columns={'Unnamed: 3':'to_stat'}, inplace=True)
    travel_tours.rename(columns={'Unnamed: 5':'Via2'}, inplace=True)
    travel_tours.rename(columns={'Unnamed: 6':'Via3'}, inplace=True)
    travel_tours.rename(columns={'Unnamed: 7':'Via4'}, inplace=True)
    travel_tours.rename(columns={'Early     ':'Early'}, inplace=True)
    travel_tours.rename(columns={'AM peak   ':'AM peak'}, inplace=True)
    travel_tours.rename(columns={'Midday    ':'Midday'}, inplace=True)
    travel_tours.rename(columns={'PM Peak   ':'PM peak'}, inplace=True)
    travel_tours.rename(columns={'Evening   ':'Evening'}, inplace=True)
    travel_tours.rename(columns={'Weekday':'total_flow'}, inplace=True)
    travel_tours.rename(columns={'Late      ':'Late'}, inplace=True)
    travel_tours = travel_tours.reset_index(drop=True)

    #clean name from_stat and to_stat
    travel_tours["from_stat"] = travel_tours["from_stat"].str.strip()
    travel_tours["to_stat"] = travel_tours["to_stat"].str.strip()
    travel_tours["Via"] = travel_tours["Via"].str.strip()

    #description of the whole network
    time_table_final = pd.read_csv(basic_path + "edges_tfl_{}mins.csv".format(interChangeTimes))

    #add lot/lang til time_table
    for row in range(len(time_table_final)):
        naptan1 = time_table_final.loc[row, 'Station1_NAPTAN']
        naptan2 = time_table_final.loc[row, 'Station1_NAPTAN.1']
        name1, lat1, long1 = station_location[naptan1]
        name2, lat2, long2 = station_location[naptan2]
        
        time_table_final.loc[row,'lat1'] = lat1
        time_table_final.loc[row,'lon1'] = long1
        time_table_final.loc[row,'lat2'] = lat2
        time_table_final.loc[row,'lon2'] = long2

    #Table and graph with just lines (not possible to change)
    time_table_final2 = time_table_final.copy()[time_table_final.Line != 'Inter']
    time_table_final2 = time_table_final2.reset_index(drop=True)
    time_table_final2 = time_table_final2.copy()[time_table_final2.Line != 'Walk']
    time_table_final2 = time_table_final2.reset_index(drop=True)

    #only include main stations
    time_table_final3 = time_table_final.copy().loc[time_table_final['Line'] == 'Inter']
    time_table_final3 = time_table_final3.reset_index(drop=True)

    return pass_table, pass_info, line_load, station_in, station_out, od_data, travel_tours, time_table_final, time_table_final2, time_table_final3

def clean_station_in(station_in):
    #clean table, remove columns with date/note/nan
    station_in = station_in.drop(station_in.columns[[2, 3, 100]], 1)
    station_in = station_in.drop(station_in.index[[268]])
    station_in = station_in.reset_index(drop=True)

    #clean station names 
    for row in range(len(station_in)):
        station1Name = station_in.loc[row, ' Station']
        station1 = fixStationName((station1Name.strip()))
        station_in.loc[row, ' Station'] = station1

    #identify AM and PM count
    for row in range(len(station_in)):
        station_in.loc[row, 'AM_count'] = sum(station_in.iloc[row, 22:34]) 
        station_in.loc[row, 'PM_count'] = sum(station_in.iloc[row, 58:70])
    return station_in

def clean_od(od_data):
    od_data = od_data.rename(columns={'Unnamed: 1': 'from_station', 'Unnamed: 3': 'to_station'})
    od_data = od_data.drop(od_data.index[[0]])
    od_data = od_data.reset_index(drop=True) 
    od_data['From'] = od_data['From'].apply(int)
    od_data['To'] = od_data['To'].apply(int)
    return od_data

def clean_station_out(station_out):
    station_out = station_out.drop(station_out.index[[0, 269]])
    station_out = station_out.drop(station_out.columns[[2, 3, 100]], 1)
    station_out = station_out.reset_index(drop=True)

    #clean station names 
    for row in range(len(station_out)):
        station1Name = station_out.loc[row, ' Station']
        station1 = fixStationName((station1Name.strip()))
        station_out.loc[row, ' Station'] = station1

    #identify AM and PM count
    for row in range(len(station_out)):
        station_out.loc[row, 'AM_count'] = sum(station_out.iloc[row, 22:34]) 
        station_out.loc[row, 'PM_count'] = sum(station_out.iloc[row, 58:70])
    return station_out

def getStationInOutFlow(time_table_final, station_in, station_out):
    stationInOutFlow = {}
    for row in range(len(time_table_final)):
        stationName = time_table_final.loc[row, 'Station1_name'].split(':')[0]
        stationName = fixStationName(stationName)
        station1 = stationName
        if station1 == "Bank / Monument":
            station1 = "Bank & Monument"
        count_in = list(station_in.loc[station_in[' Station'] == station1, " Total"])[0]
        AM_count_in = list(station_in.loc[station_in[' Station'] == station1, "AM_count"])[0]
        PM_count_in = list(station_in.loc[station_in[' Station'] == station1, "PM_count"])[0]
        count_out = list(station_out.loc[station_out[' Station'] == station1, " Total"])[0]
        AM_count_out = list(station_out.loc[station_out[' Station'] == station1, "AM_count"])[0]
        PM_count_out = list(station_out.loc[station_out[' Station'] == station1, "PM_count"])[0]
        AM_flow = "positive" if AM_count_in>AM_count_out else "negative"
        PM_flow = "positive" if PM_count_in>PM_count_out else "negative"
        Tot_flow = "positive" if count_in>count_out else "negative"
        if stationName not in stationInOutFlow:
            stationInOutFlow[stationName] = {"AM_flow": 0, "PM_flow": 0, "Total_flow": 0}
        stationInOutFlow[stationName]["AM_flow"] = AM_flow
        stationInOutFlow[stationName]["PM_flow"] = PM_flow
        stationInOutFlow[stationName]["Total_flow"] = Tot_flow
    return stationInOutFlow

def getLineLoad(line_load, pass_info, directed):
    edges = {}
    count = 0
    for row in range(len(line_load)):
        count = count + 1
        start_node = str(line_load.loc[row,'start.node'])
        end_node =  str(line_load.loc[row,'end.node'])
        station_start = getStationFromNode(start_node, pass_info)
        station_end = getStationFromNode(end_node, pass_info)
        edgeName = getEdgeName(station_start, station_end, directed)
        #timed with -1 to make maximum spanning tree 
        early = int(line_load.iloc[row,9]) #*(-1)
        ampeak = int(line_load.iloc[row,10])
        midday = int(line_load.iloc[row,11])
        pmpeak = int(line_load.iloc[row,12])
        evening = int(line_load.iloc[row,13])
        late = int(line_load.iloc[row,14])
        total = int(line_load.iloc[row,15])

        if not edgeName in edges:
            edges[edgeName] = {}
            edges[edgeName]["early"] = 0
            edges[edgeName]["ampeak"] = 0
            edges[edgeName]["midday"] = 0
            edges[edgeName]["pmpeak"] = 0
            edges[edgeName]["evening"] = 0
            edges[edgeName]["late"] = 0
            edges[edgeName]["total"] = 0
        
        edges[edgeName]["early"] = edges[edgeName]["early"] + early
        edges[edgeName]["ampeak"] = edges[edgeName]["ampeak"] + ampeak
        edges[edgeName]["midday"] = edges[edgeName]["midday"] + midday
        edges[edgeName]["pmpeak"] = edges[edgeName]["pmpeak"] + pmpeak
        edges[edgeName]["evening"] = edges[edgeName]["evening"] + evening
        edges[edgeName]["late"] = edges[edgeName]["late"] + late
        edges[edgeName]["total"] = edges[edgeName]["total"] + total

    #make a table with the data
    stations1 = []
    stations2 = []
    earlyf = []
    ampeakf = []
    middayf = []
    pmpeakf = []
    eveningf = []
    latef = []
    totalf = []
    for stations in edges:
        early = edges[stations]["early"]
        ampeak = edges[stations]["ampeak"]
        midday = edges[stations]["midday"]
        pmpeak = edges[stations]["pmpeak"]
        evening = edges[stations]["evening"]
        late = edges[stations]["late"]
        total = edges[stations]["total"]

        station1, station2 = stations.split(":")
        stations1.append(station1)
        stations2.append(station2)
        earlyf.append(int(early))
        ampeakf.append(int(ampeak))
        middayf.append(int(midday))
        pmpeakf.append(int(pmpeak))
        eveningf.append(int(evening))
        latef.append(int(late))
        totalf.append(int(total))
        
    line_load_sum = pd.DataFrame(np.column_stack([stations1, stations2, earlyf, ampeakf, middayf, pmpeakf, eveningf, latef,totalf]), 
                                   columns=['stations1', 'stations2', 'early', 'ampeak', 'midday', 'pmpeak', 'evening', 'late', 'total'])   

    # make flow numeric 
    line_load_sum['early'] = pd.to_numeric(line_load_sum['early'])
    line_load_sum['ampeak'] = pd.to_numeric(line_load_sum['ampeak'])
    line_load_sum['midday'] = pd.to_numeric(line_load_sum['midday'])
    line_load_sum['pmpeak'] = pd.to_numeric(line_load_sum['pmpeak'])
    line_load_sum['evening'] = pd.to_numeric(line_load_sum['evening'])
    line_load_sum['late'] = pd.to_numeric(line_load_sum['late'])
    line_load_sum['total'] = pd.to_numeric(line_load_sum['total'])
    return line_load_sum