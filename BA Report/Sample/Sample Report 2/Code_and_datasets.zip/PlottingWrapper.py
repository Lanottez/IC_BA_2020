import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from HelperFunctions import getStationFromNode
from collections import Counter

def plotWeightDistribution(time_table_final2, plotFormat="eps"): 
    #Graph with all edges (without links for transfers) 
    G_flow_dir = nx.from_pandas_dataframe(time_table_final2, 'Station1_name', 'Station2_name', ('Running_Time', 'Line', 'total_flow'), create_using = nx.DiGraph())

    edge_list = []
    for u, v, d in G_flow_dir.edges(data = True):
        edge_list.append(d['total_flow'])

    # Normalised Histogram
    heights, bins = np.histogram(edge_list, bins=50)
    heights = heights/float(sum(heights))
    binMids = bins[:-1] + np.diff(bins)/2.

    #PLOT
    plt.scatter(binMids, heights, color = 'steelblue')
    plt.plot(binMids, 111136*(binMids**(-1.421)), '--', linewidth=1, color = 'red')
    plt.yscale('log')
    plt.xscale('log')
    plt.savefig("plots/weight_distribution.{}".format(plotFormat), format=plotFormat, dpi = 1000)

def plotStrengthDistribution(pass_info, line_load, plotFormat="eps"):
    #Strength Distribution for stations in weighted directed graph     

    #get list of all stations
    station_list = []
    for row in range(len(pass_info)):
        if pass_info.loc[row, 'Station'] not in station_list:
            station_list.append(pass_info.loc[row, 'Station'])

    #add total in/out flow to all stations
    end_nodes = {}
    count = 0
    for row in range(len(line_load)):
        count = count + 1
        end_node = str(line_load.loc[row,'end.node'])
        station_end = getStationFromNode(end_node, pass_info)
        total = int(line_load.iloc[row,15])

        if not station_end in end_nodes:
            end_nodes[station_end] = 0
        end_nodes[station_end] = end_nodes[station_end] + total

    end_nodes["Bank & Monument"] = end_nodes["Bank"] + end_nodes["Monument"]


    start_nodes = {}
    count = 0
    for row in range(len(line_load)):
        count = count + 1
        start_node = str(line_load.loc[row,'start.node'])
        station_start = getStationFromNode(start_node, pass_info)
        total = int(line_load.iloc[row,15])

        if not station_start in start_nodes:
            start_nodes[station_start] = 0
        start_nodes[station_start] = start_nodes[station_start] + total

    start_nodes["Bank & Monument"] = start_nodes["Bank"] + start_nodes["Monument"]

    in_flow = []
    for station in station_list:
        try:
            for key, value in end_nodes.items():
                if key == station:
                    in_flow.append(value)        
        except:
            in_flow.append("not found")

    out_flow = []
    for station in station_list:
        try:
            for key, value in start_nodes.items():
                if key == station:
                    out_flow.append(value)        
        except:
            out_flow.append("not found")

    # Normalised histogram
    heights1, bins1 = np.histogram(in_flow, bins=40)
    heights2, bins2 = np.histogram(out_flow, bins=40)

    heights1 = heights1/float(sum(heights1))
    binMids1 = bins1[:-1] + np.diff(bins1)/2.
    
    heights2 = heights2/float(sum(heights2))
    binMids2 = bins2[:-1] + np.diff(bins2)/2.
    
    #Plot
    plt.subplots(figsize=(10, 6.5))
    ax1 = plt.subplot(121)
    plt.scatter(binMids1, heights1, color = 'steelblue')
    plt.plot(binMids1, 4000000000000000000*(binMids1**(-3.975)), '--', linewidth=1, color = 'red')
    plt.ylim([-0.005,0.08])
    plt.xlim([-0.5,1000000])
    plt.xticks(rotation=45)
    
    plt.subplot(122, sharey = ax1)
    plt.scatter(binMids2, heights2, color = 'steelblue')
    plt.plot(binMids1, 2000000000000000*(binMids1**(-3.289)), '--', linewidth=1, color = 'red')
    plt.ylim([-0.005,0.08])
    plt.xlim([-0.5,1000000])
    plt.xticks(rotation=45)

    plt.savefig("plots/strength_distribution.{}".format(plotFormat), format=plotFormat, dpi = 1000)

def createSpanningTree(G_max, plotFormat="eps"):
    global od_data, pass_info
    print ("Creating Spanning Tree Graph...")

    hubs = []
    d = nx.degree(G_max)
    for node, degree in d.items():
        if degree > 6:
            hubs.append(node)

    labels = {}    
    for node in G_max.nodes():
        if node in hubs:
            labels[node] = node
    plt.clf()
    pos = nx.spring_layout(G_max)
    nx.draw(G_max, pos, cmap = plt.get_cmap('hsv'), node_size=15, linewidths=0, edge_color = 'silver', with_labels = False)
    nx.draw_networkx_labels(G_max, pos, labels, font_size=8,font_color='black')
    plt.savefig("plots/spanning_tree_graph.{}".format(plotFormat), format=plotFormat, dpi = 1000)
    print ("Finished creating Spanning Tree Graph")    
    
def plotDegreeDistributionForNodesInMaximumSpanningTree(G_max, plotFormat="eps"):
    #Degree distribution for nodes in maximum spanning tree (log-log)
    tot_degrees = G_max.degree() 
    tot_values = sorted(set(tot_degrees.values()))
    tot_hist = Counter(tot_degrees.values())

    tot_hist_list = []
    count = 0
    for key in tot_hist:
        tot_hist_list.append(tot_hist[key])
        count = count + tot_hist[key]
    #Normalise
    tot_hist_list2 = []
    for item in tot_hist_list:
        new = item/float(count)
        tot_hist_list2.append(new)
    
    n = len(tot_hist_list)
    A = np.array(tot_values[0:n+1])
    B = np.array(tot_hist_list2[0:n+1])
    
    #PLOT
    plt.scatter(A, B, color = 'steelblue')
    plt.plot(A, 0.1832*(A**(-1.376)), '--', linewidth=1, color = 'red')
    plt.yscale('log')
    plt.xscale('log')
    plt.xlim([0.5,50])
    
    plt.savefig("plots/weight_spanningtree_distribution.{}".format(plotFormat), format=plotFormat, dpi = 1000)

