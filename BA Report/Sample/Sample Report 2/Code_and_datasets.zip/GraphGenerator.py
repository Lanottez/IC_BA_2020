from HelperFunctions import distanceBetweenCoordinates
import networkx as nx

def generate_G_no_platforms(time_table_final2, dict_geo):
    G_no_platforms = nx.DiGraph()
    for row in range(len(time_table_final2)):
        from_station = time_table_final2.loc[row,'Station1_name'].split(":")[0]
        to_station = time_table_final2.loc[row,'Station2_name'].split(":")[0]
        lat1 = time_table_final2.loc[row,'lat1']
        lng1 = time_table_final2.loc[row,'lon1']
        lat2 = time_table_final2.loc[row,'lat2']
        lng2 = time_table_final2.loc[row,'lon2']
        flow = time_table_final2.loc[row,'total_flow']
        dist3 = distanceBetweenCoordinates(lat1, lng1, lat2, lng2)
        lat1 = dict_geo[from_station][0]
        lng1 = dict_geo[from_station][1]
        lat2 = dict_geo[to_station][0]
        lng2 = dict_geo[to_station][1]
        dist = time_table_final2.loc[row,'Distance']
        dist2 = distanceBetweenCoordinates(lat1, lng1, lat2, lng2)
        if dist3 > dist:
            dist = dist3*1.3
        G_no_platforms.add_edge(from_station, to_station, {"Distance": dist, "total_flow": flow})
    return G_no_platforms