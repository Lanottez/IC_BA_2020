
"""
Created on Sun Jul 30 11:09:57 2017

@author: an-magrittlilleaasen
"""
'--------------------------------------------------------------------'
import requests
import pandas as pd
import matplotlib.pyplot as plt
import re
from requests.auth import HTTPBasicAuth
import numpy as np
import networkx as nx
import json
import time
from difflib import SequenceMatcher
import difflib  
from scipy.stats import powerlaw

'--------------------------------------------------------------------'
from DatasetsWrapper import readDatasets, getStationInOutFlow, getLineLoad
from PlottingWrapper import plotWeightDistribution, plotStrengthDistribution, createSpanningTree, plotDegreeDistributionForNodesInMaximumSpanningTree
from HelperFunctions import fixStationName, getLineWeights, getFlowDiff, getFlow, distanceBetweenCoordinates, splitTripOnTrainTrips, getStationLinesMapping, getPlatformsOnSubTrip, getEdgeAndNodeColors, getEdgeName, getStationFromNode, getStationFromNode2, generateOriginDestinationTable, getStationLocations, getGeoCoordsForNode
from MeasuresWrapper import getHowManyUsesShortestPath, getGraphEfficiency, getAvgEdgeBetweennessCentrality,getAvgClosenessCentrality, getAvgNodeBetweennessCentrality, getAvgClusteringCoeffisient, combination_betweenness_weight
from GraphHelper import removeWalksFromGraph, makeUndirected, getAffectedUsers, generate_G_no_platforms, k_shortest_paths, ifMissingEdgeInPath, isLogicalSamePath, getInfoOnPath
from NewPathGenerator import getRealTrips, get_optimal_route, findChangeThresholds

doReadDatasets = True
computeMeasurments = True
calculate_flow_distributions = True
doCreateSpanningTree = False
checkHowManyUsesShortestPath = False
findThresholds = True
make_day_flow_graphs = False
runK_shortest_paths = False
'--------------------------------------------------------------------'
########################################
#TfL API keys                          #
########################################
numAffectedUsersTrip = None
plotFormat = "eps" #change this between eps and jpg
interChangeTimes  = 2
tfl_id = 'de17fac4'
tfl_key = '06a55248063fed551e743f895a6e9308'
lines = ['bakerloo', 'central', 'circle', 'district', 'jubilee', 'metropolitan', 'northern', 'piccadilly', 'victoria', 'hammersmith-city', 'waterloo-city']
'--------------------------------------------------------------------'
########################################
#Read all datasets                     #
########################################
if doReadDatasets:
    print ("Reading all datasets...")
    readFromApi = True
    station_location = getStationLocations(lines, readFromApi)
    pass_table, pass_info, line_load, station_in,\
    station_out, od_data, travel_tours,\
    time_table_final, time_table_final2, time_table_final3 = readDatasets(station_location, interChangeTimes)
    print ("Finished reading all datasets")
'--------------------------------------------------------------------'
'''
Make an UNDIRECTED GRAPH with Line Load:
Dataset: Line loading by section-line-time of day 2016

Can be used for maximum spanning tree and weight distribution

'''
stationInOutFlow = getStationInOutFlow(time_table_final, station_in, station_out)
line_load_sum = getLineLoad(line_load, pass_info, directed=False)
line_load_directed = getLineLoad(line_load, pass_info, directed=True)
dict_geo = getGeoCoordsForNode(time_table_final) 
stationsWithLines = getStationLinesMapping(time_table_final2) 
'--------------------------------------------------------------------'

#Graph with all edges (also changes) 
G = nx.from_pandas_dataframe(time_table_final, 'Station1_name', 'Station2_name', ('Running_Time', 'Line', 'total_flow', 'Distance', 'early_flow', 'aM_peak_flow', 'midday_flow', 'pM_Peak_flow', 'evening_flow', 'late_flow'), create_using = nx.DiGraph())
print ("len(G.edges()):", len(G.edges()))
print ("len(G.nodes()):", len(G.nodes()))
G_no_walks = nx.from_pandas_dataframe(time_table_final.copy()[time_table_final.Line != 'Walk'].reset_index(drop=True), 'Station1_name', 'Station2_name', ('Running_Time', 'Line', 'total_flow', 'Distance'), create_using = nx.DiGraph())
print ("len(G_no_walks.edges()):", len(G_no_walks.edges()))
print ("len(G_no_walks.nodes()):", len(G_no_walks.nodes()))
G_no_platforms_directed = generate_G_no_platforms(time_table_final2, dict_geo)
G_no_platforms = makeUndirected(G_no_platforms_directed)
print ("type(G_no_platforms)", type(G_no_platforms))
print ("len(G_no_platforms.edges()):", len(G_no_platforms.edges()))
print ("len(G_no_platforms.nodes()):", len(G_no_platforms.nodes()))
max_combined, max_weight, max_betweenes, max_combined_edge, max_weight_edge, max_betweenes_edge = combination_betweenness_weight(G_no_platforms)
print ("max_combined_edge: {} ({}), max_weight_edge: {} ({}), max_betweenes_edge: {} ({})".format(max_combined_edge, max_combined, max_weight_edge, max_weight, max_betweenes_edge, max_betweenes))
'--------------------------------------------------------------------'
########################################
#Computing measurement values          #
########################################
'''
Measures of the network 
    - Closeness
    - Edge Betweenness
    - Efficiency
    - Clustering Coeffisient
'''
if computeMeasurments:

    print ("G_no_platforms:", len(G_no_platforms))
    print("Computing measurement values...")
    avgClosenessCentrality = getAvgClosenessCentrality(G_no_platforms)
    print ("avgClosenessCentrality: {}".format(avgClosenessCentrality))
    
    avgEdgeBetweennessCentrality = getAvgEdgeBetweennessCentrality(G_no_platforms)
    print ("avgEdgeBetweennessCentrality: {}".format(avgEdgeBetweennessCentrality))
    
    G_full, graphEfficiency = getGraphEfficiency(G_no_platforms, dict_geo)
    print ("graphEfficiency: {}".format(graphEfficiency))
    
    print ("type(G_no_platforms):", type(G_no_platforms))
    print ("len(G_no_platforms.edges()):", len(G_no_platforms.edges()))
    print ("len(G_no_platforms.nodes()):", len(G_no_platforms.nodes()))

    print ("type(G_full):", type(G_full))
    print ("len(G_full.edges()):", len(G_full.edges()))
    print ("len(G_full.nodes()):", len(G_full.nodes()))

    avgClusteringCoeffisient = getAvgClusteringCoeffisient(G_no_platforms)
    print ("avgClusteringCoeffisient: {}".format(avgClusteringCoeffisient))
    
    print("Finished computing measurement values")
'--------------------------------------------------------------------'
########################################
# Passenger flow distributions         #
########################################

if calculate_flow_distributions:
    
    plotWeightDistribution(time_table_final2, plotFormat)
    plotStrengthDistribution(pass_info, line_load, plotFormat)

'--------------------------------------------------------------------'  
########################################
# SPANNING TREE GRAPH                  #
########################################
    
if doCreateSpanningTree:
    od_data_df = generateOriginDestinationTable(od_data, pass_info)
    G_tree = nx.from_pandas_dataframe(od_data_df, 'stations1', 'stations2', 'total')
    G_max = nx.minimum_spanning_tree(G_tree, weight = 'total')

    createSpanningTree(G_max, plotFormat)
    plotDegreeDistributionForNodesInMaximumSpanningTree(G_max, plotFormat)


'--------------------------------------------------------------------'
'''
PLOT the full network (directed) 
    pos = geocode
    weights = flow
'''
G_undir = makeUndirected(G)

edgeColorsAM, nodeColorsAM = getEdgeAndNodeColors(G_undir, stationInOutFlow, flowType="AM_flow")
edgeColorsPM, nodeColorsPM = getEdgeAndNodeColors(G_undir, stationInOutFlow, flowType="PM_flow")

pos = dict_geo
weights2 = getLineWeights(G_undir, 'total_flow')

#Plot with AM and PM node colours
plt.clf()
nx.draw(G_undir, pos, node_size=2, linewidths=0.1, with_labels = False,  edge_color=edgeColorsAM, arrows = False, node_color = nodeColorsAM, width=weights2)
plt.savefig("plots/tube_am.{}".format(plotFormat), format=plotFormat, dpi = 1000)
plt.clf()
nx.draw(G_undir, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColorsPM, arrows = False, node_color = nodeColorsPM, width=weights2)
plt.savefig("plots/tube_pm.{}".format(plotFormat), format=plotFormat, dpi = 1000)

#Full weight plot with Total Flow 
G_no_changes = nx.from_pandas_dataframe(time_table_final2, 'Station1_name', 'Station2_name', ('Running_Time', 'Line', 'total_flow', 'early_flow', 'aM_peak_flow', 'midday_flow', 'pM_Peak_flow', 'evening_flow', 'late_flow'), create_using = nx.DiGraph())
print ("len(G_no_changes.edges()):", len(G_no_changes.edges()))
print ("len(G_no_changes.nodes()):", len(G_no_changes.nodes()))
G_no_changes_undir = makeUndirected(G_no_changes)
print ("len(G_no_changes_undir.edges()):", len(G_no_changes_undir.edges()))
print ("len(G_no_changes_undir.nodes()):", len(G_no_changes_undir.nodes()))

edgeColors2, nodeColors2 = getEdgeAndNodeColors(G_no_changes_undir, stationInOutFlow)
weights4 = getLineWeights(G_no_changes_undir, 'total_flow')

plt.clf()
nx.draw(G_no_changes_undir, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors2, arrows = False, node_color = 'white', width=weights4)
plt.savefig("plots/total_flow_weighted.{}".format(plotFormat), format=plotFormat, dpi = 1000)

#Normal plot without weights
plt.clf()
nx.draw(G_no_changes_undir, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors2, arrows = False, node_color = 'white', width=1)
plt.savefig("plots/tube_map.{}".format(plotFormat), format=plotFormat, dpi = 1000)

#Graph with missing link:
G_missing_edge = G.copy()
#removeFrom = "Bethnal Green:central"
#removeTo = "Liverpool Street:central"
#removeFrom = "Oxford Circus:victoria"
#removeTo = "Green Park:victoria"
removeFrom = "Westminster:jubilee"
removeTo = "Waterloo:jubilee"
removeFrom_node = removeFrom.split(":")[0]
removeTo_node = removeTo.split(":")[0]
flow_broken_edge = G_missing_edge[removeFrom][removeTo]["total_flow"] + G_missing_edge[removeTo][removeFrom]["total_flow"]
print ("G_missing_edge.edges() before removal: {}".format(len(G_missing_edge.edges())))
G_missing_edge.remove_edges_from([(removeFrom,removeTo), (removeTo,removeFrom)])
print ("G_missing_edge.edges() after removal: {}".format(len(G_missing_edge.edges())))

G_missing_edge_no_walks = removeWalksFromGraph(G_missing_edge)
G_missing_edge_no_walks_undir = makeUndirected(G_missing_edge_no_walks)
edgeColors1, nodeColors1 = getEdgeAndNodeColors(G_missing_edge_no_walks_undir, stationInOutFlow)
weights = getLineWeights(G_missing_edge_no_walks_undir, 'total_flow')
plt.clf()
nx.draw(G_missing_edge_no_walks_undir, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors1, arrows = False, node_color = 'white', width=weights)
plt.savefig("plots/tube_remove_{}-{}.{}".format(removeFrom_node, removeTo_node, plotFormat), format=plotFormat, dpi = 1000)

print("#G_missing_edge.nodes(): {}".format(len(G_missing_edge.nodes())))
print("#G_missing_edge.edges(): {}".format(len(G_missing_edge.edges())))

if computeMeasurments:
    G_no_platforms_missing_edge = G_no_platforms.copy()
    G_no_platforms_missing_edge.remove_edges_from([(removeFrom,removeTo), (removeTo,removeFrom)])

'--------------------------------------------------------------------'
'''
Which edge to remove
 - Betweenness
 - Weight
 - Combination
'''  
if findThresholds:
    findChangeThresholds(travel_tours, stationsWithLines, G_no_changes, G_no_walks)
   
'--------------------------------------------------------------------'
########################################
#Find affected passengers              #
########################################
'''
Find affected passengers, returns: 
    - totalAffectedUsers
    - affectedTrips
'''
affectedTrips, allTripsTaken, splittedTrips, affectedUsers, allUsers = getAffectedUsers(travel_tours, stationsWithLines, G_no_changes, removeFrom, removeTo, numTrips=numAffectedUsersTrip)
totalAffectedUsers, AMAffectedUsers, earlyAffectedUsers, middayAffectedUsers, PMAffectedUsers, eveningAffectedUsers, lateAffectedUsers = affectedUsers 
totalUsers, AMUsers, earlyUsers, middayUsers, PMUsers, eveningUsers, lateUsers = allUsers

print (totalAffectedUsers)
print ("earlyAffectedUsers: {}, of {} in that time periode ({:.2f} %)".format(earlyAffectedUsers, earlyUsers, 100*earlyAffectedUsers/float(earlyUsers)))
print ("AMAffectedUsers: {}, of {} in that time periode ({:.2f} %)".format(AMAffectedUsers, AMUsers, 100*AMAffectedUsers/float(AMUsers)))
print ("middayAffectedUsers: {}, of {} in that time periode ({:.2f} %)".format(middayAffectedUsers, middayUsers, 100*middayAffectedUsers/float(middayUsers)))
print ("PMAffectedUsers: {}, of {} in that time periode ({:.2f} %)".format(PMAffectedUsers, PMUsers, 100*PMAffectedUsers/float(PMUsers)))
print ("eveningAffectedUsers: {}, of {} in that time periode ({:.2f} %)".format(eveningAffectedUsers, eveningUsers, 100*eveningAffectedUsers/float(eveningUsers)))
print ("lateAffectedUsers: {}, of {} in that time periode ({:.2f} %)".format(lateAffectedUsers, lateUsers, 100*lateAffectedUsers/float(lateUsers)))
print ("totalAffectedUsers: {}, of {} in that time periode ({:.2f} %)".format(totalAffectedUsers, totalUsers, 100*totalAffectedUsers/float(totalUsers)))
scaleFactor = (flow_broken_edge / float(totalAffectedUsers))
#scaleFactor = 2
print ("flow_broken_edge: {}".format(flow_broken_edge))
print ("Number of affected users: {}".format(totalAffectedUsers))
print ("Scalefactor was {}".format(scaleFactor))
print ("splittedTrips was {}".format(splittedTrips))
print ("allTripsTaken: {}".format(len(allTripsTaken)))

'--------------------------------------------------------------------'
'''
Predict new flow based on affected passengers
    - remove old flow
    - add new flow
'''

#get flow data without the affected passengers
G_missing_edge_changeFlow = G_missing_edge.copy()
for trip in affectedTrips:
    totalPath, flows = trip
    early_flow, am_flow, midday_flow, pm_flow, evening_flow, late_flow, total_flow = flows
    scaled_use = total_flow * scaleFactor
    scaled_early = early_flow * scaleFactor
    scaled_am = am_flow * scaleFactor
    scaled_midday = midday_flow * scaleFactor    
    scaled_pm = pm_flow * scaleFactor
    scaled_evening = evening_flow * scaleFactor
    scaled_late = late_flow * scaleFactor

    for i in range(1, len(totalPath)):
        a = totalPath[i-1]
        b = totalPath[i]
        edge_data = G_missing_edge_changeFlow.get_edge_data(a, b)
        if edge_data != None:
            
            edgeFlow = getFlow(edge_data, "total_flow", scaled_use)
            G_missing_edge_changeFlow[a][b]["total_flow"] = edgeFlow

            edgeFlow = getFlow(edge_data, "early_flow", scaled_early)
            G_missing_edge_changeFlow[a][b]["early_flow"] = edgeFlow

            edgeFlow = getFlow(edge_data, "aM_peak_flow", scaled_am)
            G_missing_edge_changeFlow[a][b]["aM_peak_flow"] = edgeFlow

            edgeFlow = getFlow(edge_data, "midday_flow", scaled_midday)
            G_missing_edge_changeFlow[a][b]["midday_flow"] = edgeFlow

            edgeFlow = getFlow(edge_data, "pM_Peak_flow", scaled_pm)
            G_missing_edge_changeFlow[a][b]["pM_Peak_flow"] = edgeFlow

            edgeFlow = getFlow(edge_data, "evening_flow", scaled_evening)
            G_missing_edge_changeFlow[a][b]["evening_flow"] = edgeFlow

            edgeFlow = getFlow(edge_data, "late_flow", scaled_late)
            G_missing_edge_changeFlow[a][b]["late_flow"] = edgeFlow

#add new routes for affected passengers to the graph
for trip in affectedTrips:
    totalPath, flows = trip
    early_flow, am_flow, midday_flow, pm_flow, evening_flow, late_flow, total_flow = flows
    fromStation, toStation = totalPath[0], totalPath[-1]
    fromStation = fixStationName(fromStation)
    toStation = fixStationName(toStation)
    #the new path depends on approach in 4.2 and 4.3
    new_path = get_optimal_route(fromStation, toStation, G_missing_edge_changeFlow)
    scaled_use = total_flow * scaleFactor
    scaled_early = early_flow * scaleFactor
    scaled_am = am_flow * scaleFactor
    scaled_midday = midday_flow * scaleFactor
    scaled_pm = pm_flow * scaleFactor
    scaled_evening = evening_flow * scaleFactor
    scaled_late = late_flow * scaleFactor
    for i in range(1, len(new_path)):
        a = new_path[i-1]
        b = new_path[i]
        edge_data = G_missing_edge_changeFlow.get_edge_data(a, b)
        if edge_data != None and edge_data["Line"] != "Inter":
            edgeFlow = edge_data["total_flow"]
            edgeFlow = edgeFlow + scaled_use
            G_missing_edge_changeFlow[a][b]["total_flow"] = edgeFlow

            edgeFlow_early = edge_data["early_flow"]
            edgeFlow_early = edgeFlow_early + scaled_early
            G_missing_edge_changeFlow[a][b]["early_flow"] = edgeFlow_early

            edgeFlow_am = edge_data["aM_peak_flow"]
            edgeFlow_am = edgeFlow_am + scaled_am
            G_missing_edge_changeFlow[a][b]["aM_peak_flow"] = edgeFlow_am
 
            edgeFlow_midday = edge_data["midday_flow"]
            edgeFlow_midday = edgeFlow_midday + scaled_midday
            G_missing_edge_changeFlow[a][b]["midday_flow"] = edgeFlow_midday

            edgeFlow_pm = edge_data["pM_Peak_flow"]
            edgeFlow_pm = edgeFlow_pm + scaled_pm
            G_missing_edge_changeFlow[a][b]["pM_Peak_flow"] = edgeFlow_pm

            edgeFlow_evening = edge_data["evening_flow"]
            edgeFlow_evening = edgeFlow_evening + scaled_evening
            G_missing_edge_changeFlow[a][b]["evening_flow"] = edgeFlow_evening

            edgeFlow_late = edge_data["late_flow"]
            edgeFlow_late = edgeFlow_late + scaled_late
            G_missing_edge_changeFlow[a][b]["late_flow"] = edgeFlow_late
            
'--------------------------------------------------------------------'
'''
Graph with total flow
'''

print ("#G_missing_edge_changeFlow edges: ", len(G_missing_edge_changeFlow.edges()))
G_missing_edge_changeFlow_no_walks = removeWalksFromGraph(G_missing_edge_changeFlow)
print ("#G_missing_edge_changeFlow_no_walks edges: ", len(G_missing_edge_changeFlow_no_walks.edges()))

G_missing_edge_changeFlow_no_walks_undirected = makeUndirected(G_missing_edge_changeFlow_no_walks)
edgeColors3, nodeColors3 = getEdgeAndNodeColors(G_missing_edge_changeFlow_no_walks_undirected, stationInOutFlow)
weightstotal = getLineWeights(G_missing_edge_changeFlow_no_walks_undirected, 'total_flow')

plt.clf()
nx.draw(G_missing_edge_changeFlow_no_walks_undirected, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors3, arrows = False, node_color = 'white', width=weightstotal)
plt.savefig("plots/tube_new_flow_{}-{}_total.{}".format(removeFrom_node, removeTo_node, plotFormat), format=plotFormat, dpi = 1000)

if make_day_flow_graphs:
    '''
    Graph with EARLY flow
    '''
    weights2 = [G_missing_edge_changeFlow_no_walks[u][v]['early_flow'] for u,v in G_missing_edge_changeFlow_no_walks.edges()]
    total_w = sum(weights2)
    weightsearly = []
    for numb in weights2:
        new = (numb/total_w)*400
        weightsearly.append(new)
    plt.clf()
    nx.draw(G_missing_edge_changeFlow_no_walks, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors3, arrows = False, node_color = 'white', width=weightsearly)
    plt.savefig("plots/tube_new_flow_early.{}".format(plotFormat), format=plotFormat, dpi = 1000)
    
    '''
    Graph with AM flow
    '''
    weights3 = [G_missing_edge_changeFlow_no_walks[u][v]['aM_peak_flow'] for u,v in G_missing_edge_changeFlow_no_walks.edges()]
    total_w = sum(weights3)
    weightsAM = []
    for numb in weights3:
        new = (numb/total_w)*400
        weightsAM.append(new)
    plt.clf()
    nx.draw(G_missing_edge_changeFlow_no_walks, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors3, arrows = False, node_color = 'white', width=weightsAM)
    plt.savefig("plots/tube_new_flow_AM.{}".format(plotFormat), format=plotFormat, dpi = 1000)
    
    '''
    Graph with MIDDAY flow
    '''
    weights4 = [G_missing_edge_changeFlow_no_walks[u][v]['midday_flow'] for u,v in G_missing_edge_changeFlow_no_walks.edges()]
    total_w = sum(weights4)
    weightsmidday = []
    for numb in weights4:
        new = (numb/total_w)*400
        weightsmidday.append(new)
    plt.clf()
    nx.draw(G_missing_edge_changeFlow_no_walks, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors3, arrows = False, node_color = 'white', width=weightsmidday)
    plt.savefig("plots/tube_new_flow_midday.{}".format(plotFormat), format=plotFormat, dpi = 1000)
    
    '''
    Graph with PM flow
    '''
    weights5 = [G_missing_edge_changeFlow_no_walks[u][v]['pM_Peak_flow'] for u,v in G_missing_edge_changeFlow_no_walks.edges()]
    total_w = sum(weights5)
    weightsPM = []
    for numb in weights5:
        new = (numb/total_w)*400
        weightsPM.append(new)
    plt.clf()
    nx.draw(G_missing_edge_changeFlow_no_walks, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors3, arrows = False, node_color = 'white', width=weightsPM)
    plt.savefig("plots/tube_new_flow_PM.{}".format(plotFormat), format=plotFormat, dpi = 1000)
    
    '''
    Graph with EVENING flow
    '''
    weights6 = [G_missing_edge_changeFlow_no_walks[u][v]['evening_flow'] for u,v in G_missing_edge_changeFlow_no_walks.edges()]
    total_w = sum(weights6)
    weightsevening = []
    for numb in weights6:
        new = (numb/total_w)*400
        weightsevening.append(new)
    
    plt.clf()
    nx.draw(G_missing_edge_changeFlow_no_walks, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors3, arrows = False, node_color = 'white', width=weightsevening)
    plt.savefig("plots/tube_new_flow_evening.{}".format(plotFormat), format=plotFormat, dpi = 1000)
    
    '''
    Graph with LATE flow
    '''
    weights7 = [G_missing_edge_changeFlow_no_walks[u][v]['late_flow'] for u,v in G_missing_edge_changeFlow_no_walks.edges()]
    total_w = sum(weights7)
    weightslate = []
    for numb in weights7:
        new = (numb/total_w)*400
        weightslate.append(new)

    plt.clf()
    nx.draw(G_missing_edge_changeFlow_no_walks, pos, node_size=2, linewidths=0.1, with_labels = False, edge_color=edgeColors3, arrows = False, node_color = 'white', width=weightslate)
    plt.savefig("plots/tube_new_flow_late.{}".format(plotFormat), format=plotFormat, dpi = 1000)

'--------------------------------------------------------------------' 
'''
Measures after Flow Prediction 
'''
flow_change = {}
flows = ['aM_peak_flow', 'early_flow', 'evening_flow', 'late_flow', 'midday_flow', 'pM_Peak_flow', 'total_flow']
for flow in flows:
    flow_x = []
    for u, v in G.edges():
        line = G.get_edge_data(u, v)['Line']
        flow1 = G.get_edge_data(u, v)[flow]
        flow2 = G_missing_edge_changeFlow_no_walks.get_edge_data(u, v)
        if flow2 != None and flow1 != 0:
            flow3 = flow2[flow]    
            change_p = ((flow3-flow1)/flow1)*100
            change = (flow3-flow1)         
            flow_x.append((u, v, line, change, change_p))
    labels = ['station1', 'station2', 'line', 'tot_change', 'perc_change']       
    df_change = pd.DataFrame.from_records(flow_x, columns = labels)    

    flow_change[flow] = df_change

flowColumns = ['station1', 'station2', 'line', 'aM_peak_flow abs', 'aM_peak_flow %', 'early_flow abs', 'early_flow %', 'evening_flow abs', 'evening_flow %', 'late_flow abs', 'late_flow %', 'midday_flow abs', 'midday_flow %', 'pM_Peak_flow abs', 'pM_Peak_flow %', 'total_flow abs', 'total_flow %']


# Get Flow statistics per edge (for 6 time periods)
flowChanges = []
for edge in G_missing_edge.edges():
    a, b = edge
    edgeDataPreChange = G_missing_edge.get_edge_data(a, b)
    line = edgeDataPreChange["Line"]
    if line != "Walk" and line != "Inter":
        edgeDataAfterChange = G_missing_edge_changeFlow_no_walks.get_edge_data(a, b)
        aM_peak_flow_a, aM_peak_flow_p = getFlowDiff(edgeDataAfterChange, edgeDataPreChange, "aM_peak_flow")
        early_flow_a, early_flow_p = getFlowDiff(edgeDataAfterChange, edgeDataPreChange, "early_flow")
        evening_flow_a, evening_flow_p = getFlowDiff(edgeDataAfterChange, edgeDataPreChange, "evening_flow")
        late_flow_a, late_flow_p = getFlowDiff(edgeDataAfterChange, edgeDataPreChange, "late_flow")
        midday_flow_a, midday_flow_p = getFlowDiff(edgeDataAfterChange, edgeDataPreChange, "midday_flow")
        pM_Peak_flow_a, pM_Peak_flow_p = getFlowDiff(edgeDataAfterChange, edgeDataPreChange, "pM_Peak_flow")
        total_flow_a, total_flow_p = getFlowDiff(edgeDataAfterChange, edgeDataPreChange, "total_flow")
        if "Embankment" in a or "Embankment" in b:
            print (a, b, edgeDataAfterChange, edgeDataPreChange)
        flowChanges.append((a, b, line, aM_peak_flow_a, aM_peak_flow_p, early_flow_a, early_flow_p, evening_flow_a, evening_flow_p, late_flow_a, late_flow_p, midday_flow_a, midday_flow_p, pM_Peak_flow_a, pM_Peak_flow_p, total_flow_a, total_flow_p))
df_edgeFlow_changes = pd.DataFrame(flowChanges, columns = flowColumns)
df_edgeFlow_changes_filename = "df_edgeFlow_changes_{}-{}.csv".format(removeFrom_node, removeTo_node)
df_edgeFlow_changes.to_csv(df_edgeFlow_changes_filename)

edgeFlow_change_avg = df_edgeFlow_changes.groupby('line')['aM_peak_flow abs', 'aM_peak_flow %', 'early_flow abs', 'early_flow %', 'evening_flow abs', 'evening_flow %', 'late_flow abs', 'late_flow %', 'midday_flow abs', 'midday_flow %', 'pM_Peak_flow abs', 'pM_Peak_flow %', 'total_flow abs', 'total_flow %'].mean()
edgeFlow_change_sum = df_edgeFlow_changes.groupby('line')['aM_peak_flow abs', 'aM_peak_flow %', 'early_flow abs', 'early_flow %', 'evening_flow abs', 'evening_flow %', 'late_flow abs', 'late_flow %', 'midday_flow abs', 'midday_flow %', 'pM_Peak_flow abs', 'pM_Peak_flow %', 'total_flow abs', 'total_flow %'].sum()
edgeFlow_change_std = df_edgeFlow_changes.groupby('line')['aM_peak_flow abs', 'aM_peak_flow %', 'early_flow abs', 'early_flow %', 'evening_flow abs', 'evening_flow %', 'late_flow abs', 'late_flow %', 'midday_flow abs', 'midday_flow %', 'pM_Peak_flow abs', 'pM_Peak_flow %', 'total_flow abs', 'total_flow %'].std()
edgeFlow_change_sem = df_edgeFlow_changes.groupby('line')['aM_peak_flow abs', 'aM_peak_flow %', 'early_flow abs', 'early_flow %', 'evening_flow abs', 'evening_flow %', 'late_flow abs', 'late_flow %', 'midday_flow abs', 'midday_flow %', 'pM_Peak_flow abs', 'pM_Peak_flow %', 'total_flow abs', 'total_flow %'].sem()

print ("Saved df_edgeFlow_changes as", df_edgeFlow_changes_filename)
df_edgeFlow_changes_avg_filename = "df_edgeFlow_changes_avg_{}-{}.csv".format(removeFrom_node, removeTo_node)
df_edgeFlow_changes_sum_filename = "df_edgeFlow_changes_sum_{}-{}.csv".format(removeFrom_node, removeTo_node)
df_edgeFlow_changes_std_filename = "df_edgeFlow_changes_std_{}-{}.csv".format(removeFrom_node, removeTo_node)
df_edgeFlow_changes_sem_filename = "df_edgeFlow_changes_sem_{}-{}.csv".format(removeFrom_node, removeTo_node)
edgeFlow_change_avg.to_csv(df_edgeFlow_changes_avg_filename)
edgeFlow_change_sum.to_csv(df_edgeFlow_changes_sum_filename)
edgeFlow_change_std.to_csv(df_edgeFlow_changes_std_filename)
edgeFlow_change_sem.to_csv(df_edgeFlow_changes_sem_filename)
'--------------------------------------------------------------------'
'''
Calculations based on flow_change
'''
# Change in lines
line_change_sum = df_change.groupby('line')['tot_change'].sum()
line_change_mean = df_change.groupby('line')['perc_change'].mean()

# Change in links
link_abs_top = df_change.sort_values(['tot_change'], ascending = False).head(10)
link_abs_bottom = df_change.sort_values(['tot_change'], ascending = True).head(10)
link_perc_top = df_change.sort_values(['perc_change'], ascending = False).head(10)
link_perc_bottom = df_change.sort_values(['perc_change'], ascending = True).head(10)

'--------------------------------------------------------------------'
'''
Changes in measures after link removal
'''
if computeMeasurments:
    print("Computing measurement values...")
    avgClosenessCentrality2 = getAvgClosenessCentrality(G_no_platforms_missing_edge)
    print ("avgClosenessCentrality2: {}".format(avgClosenessCentrality2))
    avgEdgeBetweennessCentrality2 = getAvgEdgeBetweennessCentrality(G_no_platforms_missing_edge)
    print ("avgEdgeBetweennessCentrality2: {}".format(avgEdgeBetweennessCentrality2))

    G_full2, graphEfficiency2 = getGraphEfficiency(G_no_platforms_missing_edge, dict_geo)
    avgClusteringCoeffisient2 = getAvgClusteringCoeffisient(G_no_platforms_missing_edge)

    diff_clos = avgClosenessCentrality2 - avgClosenessCentrality
    diff_betw = avgEdgeBetweennessCentrality2 - avgEdgeBetweennessCentrality
    diff_eff = graphEfficiency2 - graphEfficiency
    #diff_clust = avgClusteringCoeffisient2 - avgClusteringCoeffisient

    print ("Diff_avgClosenessCentrality: {}".format(diff_clos))
    print ("Diff_avgEdgeBetweennessCentrality: {}".format(diff_betw))
    print ("Diff_graphEfficiency: {}".format(diff_eff))
    #print ("Diff_avgClusteringCoeffisient: {}".format(diff_clust))

    print("Finished computing measurement values")


'--------------------------------------------------------------------'
'''
How many uses shortest path 
Use route set to find their path
'''
if checkHowManyUsesShortestPath:
    getHowManyUsesShortestPath(allTripsTaken, G_no_walks, G, travel_tours)

