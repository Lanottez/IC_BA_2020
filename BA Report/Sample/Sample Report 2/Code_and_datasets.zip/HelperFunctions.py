import pandas as pd
import numpy as np
import json
from math import sqrt
import networkx as nx
import requests
from math import sin, cos, atan2, sqrt, radians

def fixStationName(station):
    station = station.replace("'", "")
    station = station.replace(".", "")
    if "Heathrow Terminals 1, 2 & 3" in station:
        station = "Heathrow Terminals 1-2-3"
    elif station == "Shepherds Bush (Cen)":
        station = "Shepherds Bush (Central)"
    elif station == "Shepherds Bush (H&C)":
        station = "Shepherds Bush Market"
    elif "Hammersmith (Dis)" == station:
        station = "Hammersmith (Dist&Picc Line)"
    elif station == "Hammersmith (H&C)":
        station = "Hammersmith (H&C Line)"
    elif "addington" in station:
        station = "Paddington"
    elif station == "St James Park":
        station = "St Jamess Park"
    elif station == "Bromley By Bow":
        station = "Bromley-by-Bow"
    elif station == "Harrow-On-The-Hill":
        station = "Harrow-on-the-Hill"
    elif "Baker Street" in station:
        station = "Baker Street"
    elif "Kennington" in station:
        station = "Kennington"
    elif station == "Kings Cross":
        station = "Kings Cross St Pancras"
    elif "Euston (" in station or station == "Euston Br":
        station = "Euston"
    elif station == "Edgware Road (Cir)":
        station = "Edgware Road"
    elif "Edgware Road " in station:
        station = "Edgware Road (Bakerloo)"
    elif station == "Finchley Central (Hb)":
        station = "Finchley Central"
    elif station == "Highbury":
        station = "Highbury & Islington"
    elif station == "Heathrow 123" or station == "Heathrow Terminals 123":
        station = "Heathrow Terminals 1-2-3"
    elif station == "Heathrow Terminal Four":
        station = "Heathrow Terminal 4"
    elif station == "Walthamstow":
        station = "Walthamstow Central"
    elif station == "Liverpool Street (London) Br":
        station = "Liverpool Street"
    return station

def getEdgeName(station1, station2, directed):
    if directed and station1 > station2:
        return station2 + ":" + station1
    else:
        return station1 + ":" + station2

def getStationFromNode(node, pass_info):
    station1 = pass_info.loc[pass_info['Node'] == str(node), "Station"]
    station2 = pd.Series(station1).values[0]
    return(station2)

def getStationFromNode2(node, pass_info):
    station1 = pass_info.loc[pass_info['NLC'] == int(node), "Station"]
    station2 = pd.Series(station1).values[0]
    return(station2)

def generateOriginDestinationTable(od_data, pass_info):
    journeys = {}
    count = 0
    for row in range(len(od_data)):
        count = count + 1
        start_node = str(od_data.loc[row,'From'])
        end_node =  str(od_data.loc[row,'To'])
        station_start = getStationFromNode2(start_node, pass_info)
        station_end = getStationFromNode2(end_node, pass_info)
        edgeName = getEdgeName(station_start, station_end, directed = False)
        #timed with -1 to make maximum spanning tree 
        total = int(od_data.iloc[row,10])

        if not edgeName in journeys:
            journeys[edgeName] = 0
        
        journeys[edgeName] = journeys[edgeName] + total
    #make a table with the data
    od_stations1 = []
    od_stations2 = []
    od_total = []
    for stations in journeys:
        total = journeys[stations]
        station1, station2 = stations.split(":")
        od_stations1.append(station1)
        od_stations2.append(station2)
        od_total.append(int(total))
        
    od_data_df = pd.DataFrame(np.column_stack([od_stations1, od_stations2, od_total]), 
                                   columns=['stations1', 'stations2', 'total'])   
    od_data_df['total'] = pd.to_numeric(od_data_df['total'])

    od_data_df['total'] = od_data_df['total']*(-1)
    return od_data_df

def getStationLocations(lines, readFromApi):
    station_location = {}
    if readFromApi:
        '''
	    Add location to time_table_final
	    (need this for plotting the underground network)
	    '''
        #get lat/long for all stations
        for line in lines:
            url = "https://api.tfl.gov.uk/Line/{}/StopPoints".format(line)
            print (url)
            jstop = requests.get(url, auth=HTTPBasicAuth(tfl_key, '')).json()
            filename = "stationdata/stations-{}.txt".format(line)
            print ("Write json to file:", filename)
            with open(filename, 'w') as outfile:
                json.dump(jstop, outfile)
            time.sleep(1)
    for line in lines:
        filename = "stationdata/stations-{}.txt".format(line)
        with open(filename) as data_file:    
            jstop = json.load(data_file)
        for diction in jstop:
            if 'tube' in diction['modes'] and diction['naptanId'] not in station_location:
                naptan_id = diction['naptanId']
                lng = diction['lon']
                lat = diction['lat']
                name = diction['commonName']    
                station_location[naptan_id] = (name, lat, lng)
    return station_location

def getGeoCoordsForNode(time_table_final):
    dict_geo = {}
    for row in range(len(time_table_final)):
        station1 = time_table_final.loc[row,'Station1_name']
        station2 = time_table_final.loc[row,'Station2_name']
        lat1 = time_table_final.loc[row,'lat1']
        long1 = time_table_final.loc[row,'lon1']
        lat2 = time_table_final.loc[row,'lat2']
        long2 = time_table_final.loc[row,'lon2']
        if station1 not in dict_geo:
            dict_geo[station1] = (long1, lat1)
        if station2 not in dict_geo:
            dict_geo[station2] = (long2, lat2)
    return dict_geo

def getLineWeights(G, attribute):
    weights1 = [G[u][v][attribute] for u,v in G.edges()]
    total_w = sum(weights1)
    weights2 = []
    for numb in weights1:
        new = (numb/float(total_w))*300
        weights2.append(new)
    return weights2

def getEdgeAndNodeColors(G, stationInOutFlow, flowType="PM_flow"):
    #FlowType can be ["AM_flow", "PM_flow", "Total_flow"]
    colorMapEdges = {"bakerloo": "brown", "walk": "grey", 'inter': 'grey', 'district': "green", 'hammersmith-city': 'pink', 'circle': 'yellow', "central": "red", 'metropolitan': "purple", "northern": "black", "victoria": "skyblue", "piccadilly": "blue", "jubilee": "gray", 'waterloo-city': 'palegreen'}
    colorMapNodes = {'positive': 'black', 'negative': 'white'}
    edgeColors = []
    nodeColors = []
    for edge in G.edges():
        a, b = edge
        line = G.get_edge_data(a, b)["Line"].lower()
        edgeColors.append(colorMapEdges[line])
    for node in G.nodes():
        station = node.split(":")[0]
        station = fixStationName(station)
        flow = stationInOutFlow[station][flowType]
        nodeColors.append(colorMapNodes[flow])
    return edgeColors, nodeColors

def global_efficiency(G, weight, isComplete=False):
    # cited: Eisenman, 2013 
    N = int(len(G))
    print ("N:", N, "Weight:", weight)
    if N < 2:
        return 0
    inv_lengths = []
    if isComplete:
        print ("Using fast computations with complete graph")
        for node in G.nodes():
            lengths = nx.degree(G, node, weight = weight)
            inv = []
            for edge in G.out_edges(node, data=True):
                a, b, edge_info = edge
                distance = edge_info["Distance"]
                if distance > 0:
                    inv.append(1/float(distance))
            inv_lengths.extend(inv)
        return sum(inv_lengths)/float((N*(N-1)))
    else:
        print ("Using slow computations using single_source_dijkstra_path_length")
        index = 1
        for node in G.nodes():
            if index % 40 == 0:
                print ("Working on: {}, have done {} of {}".format(node, index, N))

            index += 1
            lengths = nx.single_source_dijkstra_path_length(G, node, weight=weight)
            inv = [1/float(x) for x in lengths.values() if x != 0]
            inv_lengths.extend(inv)

        return sum(inv_lengths)/float((N*(N-1)))

def distanceBetweenCoordinates(lat1, lng1, lat2, lng2):
#cited: AaronD (2013)
    lat1 = radians(lat1)
    lng1 = radians(lng1)
    lat2 = radians(lat2)
    lng2 = radians(lng2)
    R = 6373.0
    d_lat = lat2-lat1
    d_lng = lng2-lng1
    a = sin(d_lat/float(2))**2 + cos(lat1)*cos(lat2)*sin(d_lng/float(2))**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))
    return R*c

def getFlow(edge_data, flow_type, scaled_use):
    edgeFlow = edge_data[flow_type]
    if edgeFlow < scaled_use:
        edgeFlow = 0
    else:
        edgeFlow = edgeFlow - scaled_use
    return edgeFlow

def getPlatformsOnSubTrip(fromStation, toStation, stationsWithLines):
    fromStation = fixStationName(fromStation)
    toStation = fixStationName(toStation)
    if toStation not in stationsWithLines or fromStation not in stationsWithLines:
        return None, None
    fromLines = stationsWithLines[fromStation]
    toLines = stationsWithLines[toStation]
    commonLines = set(fromLines) & set(toLines)
    if fromStation == toStation:
        return "None", None
    elif len(commonLines) > 0:
        if "Edgware Road" in toStation and "bakerloo" in commonLines:
            toStation = "Edgware Road (Bakerloo)"
        from_platform = str(fromStation + ':' + list(commonLines)[0])
        to_platform = str(toStation + ':' + list(commonLines)[0])
        return from_platform, to_platform
    else:
        return None, None

def getStationLinesMapping(time_table_final2):
    stationsWithLines = {}
    for row in range(len(time_table_final2)):
        station1Name, station1Line = time_table_final2.loc[row, 'Station1_name'].split(':')
        station1Name = fixStationName(station1Name)
        if not station1Name in stationsWithLines:
            stationsWithLines[station1Name] = set()
        stationsWithLines[station1Name].add(station1Line)
     
        station2Name, station2Line = time_table_final2.loc[row, 'Station2_name'].split(':')
        station2Name = fixStationName(station2Name)
        if not station2Name in stationsWithLines:
            stationsWithLines[station2Name] = set()
        stationsWithLines[station2Name].add(station2Line)
    return stationsWithLines
    
def getFlowDiff(edgeDataAfterChange, edgeDataPreChange, flowType):
    a = edgeDataAfterChange[flowType]-edgeDataPreChange[flowType]
    if  float(edgeDataPreChange[flowType]) > 0:       
        p = a / float(edgeDataPreChange[flowType])
    else:
        p = 0
    return a, p

def splitTripOnTrainTrips(changeStationsInTrip, stationsWithLines):
    subTripNum = 0
    subTrips = [[]]
    for i in range(1, len(changeStationsInTrip)):
        a = changeStationsInTrip[i-1]
        b = changeStationsInTrip[i]
        a_plat, b_plat = getPlatformsOnSubTrip(a, b, stationsWithLines)
        if a_plat != None and b_plat != None:
            subTrips[subTripNum].append(a_plat)
            subTrips[subTripNum].append(b_plat)
        elif a_plat == None and b_plat == None:
            subTripNum = subTripNum + 1
            subTrips.append([])
    return subTrips