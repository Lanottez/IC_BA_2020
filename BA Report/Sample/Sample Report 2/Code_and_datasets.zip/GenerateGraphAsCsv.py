import pandas as pd
import requests
import xml.etree.ElementTree
import requests
import pandas as pd
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import re
import json
from requests.auth import HTTPBasicAuth
import numpy as np
import networkx as nx
from collections import Counter
import time
import collections
from math import sin, cos, atan2, sqrt, radians

interChangeTimes = 3
readXML = False
keep_stations = ["Oxford Circus", "Bond Street", "Marble Arch", "Tottenham Court Road", "Piccadilly Circus", "Leicester Square", "Green Park", "Covent Garden", "Holborn"]
if readXML:
    e = xml.etree.ElementTree.parse('stations-facilities.xml').getroot()

    for atype in e.find('stations'):
        for station in atype.iter('station'):
            _type = station.attrib["type"]
            _name = station.find("name").text
            _lines = []
            try:
                for lines in station.findall("servingLines"):
                    for line in lines.findall("servingLine"):
                        _lines.append(line.text)
                        print (_name, _type, _lines)
            except:
                print (_name, _type)
            if "lymp" in _name:
                print ("\t\t\t", _name)
lines = ['Jubilee', 'Bakerloo', 'Central', 'District', 'Metropolitan', 'Piccadilly', 'Victoria', 'Waterloo-City', 'Circle', 'Hammersmith-City', 'Northern']

readFromApi = False
if readFromApi:
	tfl_id = 'de17fac4'
	tfl_key = '06a55248063fed551e743f895a6e9308'
	for line in lines:
		lineName = line.lower()
		url = "https://api.tfl.gov.uk/Line/{}/StopPoints".format(lineName)
		jstop = requests.get(url, auth=HTTPBasicAuth(tfl_key, ''))
		jstop2 = jstop.json()
		filename = "stations-{}.txt".format(lineName)
		with open(filename, 'w') as outfile:
			json.dump(jstop2, outfile)
		time.sleep(5)

stations = {}
for line in lines:
	lineName = line.lower()
	filename = "stations-{}.txt".format(lineName)
	with open(filename) as data_file:    
		data = json.load(data_file)
	for station in data:
		name = station["commonName"].replace("-Underground", "")
		name = name.replace("Underground", "")
		name = name.replace("Station", "")
		name = name.replace(".", "")
		name = name.replace("'", "")
		name = name.strip()
		lines = []
		for line in station["lineModeGroups"]:
			if line["modeName"] == "tube":
				lines = line["lineIdentifier"]
		if "Edgware Road" in name and len(lines)>1:
			name = "Edgware Road"
		if "Paddington" in name:
			name = "Paddington"
		if "Bank" in name or "Monument" in name:
			name = "Bank / Monument"
		if name not in stations:
			lat, lng = station["lat"], station["lon"]
			stations[name] = {"lines": lines, "lat": lat, "lng": lng}

distance_stations = pd.read_excel("distance_stations.xls", header=1, sheetname="Runtime")
StationNodesDescription = pd.read_csv("StationNodesDescription.csv", header=0)
lineLoadDF = pd.read_excel("lineload.xls", skiprows=2)

def fixStationName(station, line):
	if "Bank" in station or "Monument" in station:
		station = "Bank / Monument"
	if "Edgware Road" in station:
		if line == "bakerloo":
			station = "Edgware Road (Bakerloo)"
		else:
			station = "Edgware Road"
	elif "Hammersmith" in station:
		if line == "district" or line == "piccadilly":
			station = "Hammersmith (Dist&Picc Line)"
		else:
			station = "Hammersmith (H&C Line)"
	elif "Shepherds Bush" == station and line == "central":
		station = "Shepherds Bush (Central)"
	elif "Shepherds Bush" == station and line == "h-c":
		station = "Shepherds Bush Market"
	elif "Heathrow Terminals 1, 2 & 3" in station:
		station = "Heathrow Terminals 1-2-3"
	elif "addington" in station and line == "h-c":
		station = "Paddington"
	elif "addington" in station and line == "circle":
		station = "Paddington"
		#station = "Paddington"
	elif "addington" in station and line == "district":
		station = "Paddington"
	elif station == "St James Park":
		station = "St Jamess Park"
	elif station == "Bromley By Bow":
		station = "Bromley-by-Bow"
	elif station == "Harrow-On-The-Hill":
		station = "Harrow-on-the-Hill"
	elif "Baker Street" in station:
		station = "Baker Street"
	elif "Kennington" in station:
		station = "Kennington"
	elif station == "Kings Cross":
		station = "Kings Cross St Pancras"
	elif "Euston (" in station:
		station = "Euston"
	elif station == "Finchley Central (Hb)":
		station = "Finchley Central"
	elif station == "Highbury":
		station = "Highbury & Islington"
	elif station == "Heathrow 123":
		station = "Heathrow Terminals 1-2-3"
	elif station == "Heathrow Terminal Four":
		station = "Heathrow Terminal 4"
	elif station == "Walthamstow":
		station = "Walthamstow Central"
	return station

distanceDict = {}
for index in range(0, len(distance_stations)):
	line = distance_stations.loc[index, "Line"].replace(" & ","-").lower().strip()
	fromStat = distance_stations.loc[index, "Station from (A)"].title().replace("'", "").strip()
	toStat = distance_stations.loc[index, "Station to (B)"].title().replace("'", "").strip()
	distance = distance_stations.loc[index, "Distance (Kms)"]
	running_Time = distance_stations.loc[index, "Un-impeded Running Time (Mins)"]
	aM_peak_Running_Time = distance_stations.loc[index, "AM peak (0700-1000) Running Time (Mins)"]
	inter_peak_Running_Time = distance_stations.loc[index, "Inter peak (1000 - 1600) Running time (mins)"]
	fromStat = fixStationName(fromStat, line)
	toStat = fixStationName(toStat, line)
	if fromStat not in distanceDict:
		distanceDict[fromStat] = {}
	skipBetweenStations = ["Shepherds Bush Market", "Latimer Road"]
	if fromStat in skipBetweenStations and toStat in skipBetweenStations:
		pass
	else:
		distanceDict[fromStat][toStat] = [distance, running_Time, aM_peak_Running_Time, inter_peak_Running_Time]

distanceDict["Wood Lane"] = {}
distanceDict["Shepherds Bush Market"]["Wood Lane"] = [0.5, 0.815, 1,1]
distanceDict["Wood Lane"]["Shepherds Bush Market"] = [0.5, 0.815, 1,1]
distanceDict["Latimer Road"]["Wood Lane"] = [0.5, 0.815, 1,1]
distanceDict["Wood Lane"]["Latimer Road"] = [0.5, 0.815, 1,1]

distanceDict["Heathrow Terminal 5"] = {}
distanceDict["Heathrow Terminal 5"]["Heathrow Terminals 1-2-3"] = [0.5, 0.815, 1,1]
distanceDict["Heathrow Terminals 1-2-3"]["Heathrow Terminal 5"] = [0.5, 0.815, 1,1]
distanceDict["Hatton Cross"]["Heathrow Terminals 1-2-3"] = [0.5, 0.815, 1,1]
nodeStation = {}
nodeLine = {}
nodeNAPTAN = {}
for index in range(0, len(StationNodesDescription)):
	node = StationNodesDescription.loc[index, "Node"]
	NAPTAN = StationNodesDescription.loc[index, "NAPTAN"]
	station = StationNodesDescription.loc[index, "Station"].replace("'", "").strip()
	line = str(StationNodesDescription.loc[index, "Line"]).replace(" & ","-").lower()
	if "8323" in str(node) and "aterloo" in station:
		node = 8218
	station = fixStationName(station, line)
	nodeStation[node] = station
	nodeLine[node] = line
	nodeNAPTAN[station] = NAPTAN

def getDistanceInfo(fromStation, toStation):
	global distanceDict
	dist = distanceDict[fromStation][toStation]
	return dist

od = collections.OrderedDict(sorted(stations.items()))

df = pd.DataFrame(columns=('Station1_name', 'Station1_NAPTAN', 'Station2_name', 'Station1_NAPTAN', 'Line', "Distance", "Running_Time", "AM_peak_Running_Time", "Inter_peak_Running_Time", "total_flow", "early_flow", "aM_peak_flow", "midday_flow", "pM_Peak_flow", "evening_flow", "late_flow"))
df_cut = pd.DataFrame(columns=('Station1_name', 'Station1_NAPTAN', 'Station2_name', 'Station1_NAPTAN', 'Line', "Distance", "Running_Time", "AM_peak_Running_Time", "Inter_peak_Running_Time", "total_flow", "early_flow", "aM_peak_flow", "midday_flow", "pM_Peak_flow", "evening_flow", "late_flow"))
index = 0
cut_index = 0

for station, station_info in od.iteritems():
	lines = station_info["lines"]
	for line in lines:
		platform = "{}:{}".format(station, line)
		flows = [0, 0, 0, 0, 0, 0, 0]
		df.loc[index] = [station, nodeNAPTAN[station], platform, nodeNAPTAN[station], "Inter", 0, interChangeTimes, interChangeTimes, interChangeTimes] + flows
		df.loc[index+1] = [platform, nodeNAPTAN[station], station, nodeNAPTAN[station], "Inter", 0, 0,0,0] + flows
		if station in keep_stations:
			df_cut.loc[cut_index] = [station, nodeNAPTAN[station], platform, nodeNAPTAN[station], "Inter", 0, interChangeTimes, interChangeTimes, interChangeTimes] + flows
			df_cut.loc[cut_index+1] = [platform, nodeNAPTAN[station], station, nodeNAPTAN[station], "Inter", 0, 0,0,0] + flows
			cut_index = cut_index + 2
		index = index + 2

for row in range(0, len(lineLoadDF)):
	startNode = lineLoadDF.loc[row, "start node"]
	endNode = lineLoadDF.loc[row, "end node"]
	line = lineLoadDF.loc[row, "line"].replace(" & ","-").strip().lower()
	early_flow = lineLoadDF.loc[row, "Early     "]
	aM_peak_flow = lineLoadDF.loc[row, "AM peak   "]
	midday_flow = lineLoadDF.loc[row, "Midday    "]
	pM_Peak_flow = lineLoadDF.loc[row, "PM Peak   "]
	evening_flow = lineLoadDF.loc[row, "Evening   "]
	late_flow = lineLoadDF.loc[row, "Late      "]
	totalFlow = lineLoadDF.loc[row, "Total"]
	flows = [totalFlow, early_flow, aM_peak_flow, midday_flow, pM_Peak_flow, evening_flow, late_flow]
	startStation = nodeStation[startNode].strip()
	endStation = nodeStation[endNode].strip()
	startNAPTAN = nodeNAPTAN[startStation].strip()
	endNAPTAN = nodeNAPTAN[endStation].strip()
	checkLine = nodeLine[startNode].strip()
	distance, running_Time, aM_peak_Running_Time, inter_peak_Running_Time = getDistanceInfo(startStation, endStation)
	startPlatform = "{}:{}".format(startStation, line)
	endPlatform = "{}:{}".format(endStation, line)
	df.loc[index] = [startPlatform, startNAPTAN, endPlatform, endNAPTAN, line, distance, running_Time, aM_peak_Running_Time, inter_peak_Running_Time] + flows
	if startStation in keep_stations and endStation in keep_stations:
		df_cut.loc[cut_index] = [startPlatform, startNAPTAN, endPlatform, endNAPTAN, line, distance, running_Time, aM_peak_Running_Time, inter_peak_Running_Time] + flows
		cut_index = cut_index + 1
	index = index + 1

def distanceBetweenCoordinates(lat1, lng1, lat2, lng2):
#cited from AaronD (2013)
	lat1 = radians(lat1)
	lng1 = radians(lng1)
	lat2 = radians(lat2)
	lng2 = radians(lng2)
	R = 6373.0
	d_lat = lat2-lat1
	d_lng = lng2-lng1
	a = sin(d_lat/float(2))**2 + cos(lat1)*cos(lat2)*sin(d_lng/float(2))**2
	c = 2 * atan2(sqrt(a), sqrt(1-a))
	return R*c
addWalks = True
if addWalks:
	for station1 in stations:
		lat1, lng1 = stations[station1]["lat"], stations[station1]["lng"]
		for station2 in stations:
			if station1 != station2:
				lat2, lng2 = stations[station2]["lat"], stations[station2]["lng"]
				distance = distanceBetweenCoordinates(lat1, lng1, lat2, lng2)
				if distance < 1:
					time = 2 + (distance * 1000 /float(1.4*60))
					time = int(time)
					flows = [0, 0, 0, 0, 0, 0, 0]
					df.loc[index] = [station1, nodeNAPTAN[station1], station2, nodeNAPTAN[station2], "Walk", distance, time,time,time] + flows
					if station1 in keep_stations:
						df_cut.loc[cut_index] = [station1, nodeNAPTAN[station1], station2, nodeNAPTAN[station2], "Walk", distance, time,time,time] + flows
						cut_index = cut_index + 1

					index = index + 1
df_sorted = df.sort_values(by=['Station1_name','Station2_name','Line'])
df_sorted.to_csv("edges_tfl_{}mins.csv".format(interChangeTimes))


df_cut_sorted = df_cut.sort_values(by=['Station1_name','Station2_name','Line'])
df_cut_sorted.to_csv("edges_tfl_{}mins_sample.csv".format(interChangeTimes))
