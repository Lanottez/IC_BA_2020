# Init pyspark
print("Importing data to MongoDB...")
import pymongo
import json
import pprint
import pandas as pd
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pymongo import MongoClient

sc = SparkContext.getOrCreate()

sqlContext = SQLContext(sc)
# Connect
client = MongoClient("mongodb://mongo:27017")
db = client.db

#Importing data
print("Importing zips...")
zips = sc.textFile("/zips.json")
zips_json = zips.map(json.loads)

print("Importing prescriptions...")
prescriptions = sc.textFile("/prescriptions.jsonl")
prescriptions_json = prescriptions.map(lambda x: x.replace('.', '-')).map(json.loads)

db.zipcodes.drop()
db.prescriptions.drop()

# insert records into MongoDB
db.zipcodes.insert_many([i for i in zips_json.collect()])
db.prescriptions.insert_many([i for i in prescriptions_json.collect()])

#Test correct connection
client.list_database_names()

print("Importing finished.")

