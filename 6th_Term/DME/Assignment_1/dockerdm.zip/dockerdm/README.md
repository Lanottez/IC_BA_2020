# Coursework setup for "Data Management & Ethics"

## Instructions

1. [Install Docker Compose](https://docs.docker.com/compose/install/)
2. Clone this repository and `cd` into the directory:

    `https://gitlab.doc.ic.ac.uk/theinis/dockerdm.git`
    
    `cd dockerdm`

3. Start the docker containers:

    `docker compose up`
    
4. Start the Jupyter notebook in your browser: [http://localhost:8888](http://localhost:8888)

    Opening that URL will take you to the notebook server.
5. Open the notebook and do the assignment
6. Download the final notebook (with results) in both `.ipynb` and `.html` formats
